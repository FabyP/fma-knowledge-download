//
//  DefaultDataLoader.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
 * Class to define default data in core data store at the first start
 */
public class DefaultDataLoader {
    
    static func preloadData() {
        preloadLessons()
    }
    
    static func  preloadOwl() {
        let owl = Owl(name: "Owlsome", reachedPoints: 0)
        do {
            try owl?.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Could not create default owl: ", error)
        }
    }
    
    private static func preloadLessons() {
        preloadLesson_01()
        preloadLesson_02()
        preloadLesson_03()
        preloadLesson_04()
        preloadLesson_05()
    }
    
    private static func preloadLesson_01() {
        let lesson_01 = Lesson(name: "The Basics", imageName: "basics", intendedNumberOfExercises: 3)
        
        let lection_01 = Lection(title: "Welcome to the first lection", index: 0)
        let lectionText_11 = LectionText(isCode: false, text: "Learning to code swiftly can be fun and easy. Let's start by saying \"Hi\".", index: 0)
        let lectionText_12 = LectionText(isCode: true, text: "var greeting = \"Hi\"\nprint(greeting)", index: 1)
        let lectionText_13 = LectionText(isCode: false, text: "The code created a variable var called greeting and set its value to \"Hi\"\nAfter that the code is printed on the console.", index: 2)
        lection_01?.addToLectionTextes(lectionText_11!)
        lection_01?.addToLectionTextes(lectionText_12!)
        lection_01?.addToLectionTextes(lectionText_13!)
        lesson_01?.addToLectionList(lection_01!)
        
        let lection_02 = Lection(title: "Constants and Variables", index: 1)
        let lectionText_21 = LectionText(isCode: false, text: "Constants and variables associate a name with a value of a particular type. The value of a constant can't be changed once it's set, whereas a variable can be set to a different value in the future.", index: 0)
        let lectionText_22 = LectionText(isCode: true, text: "let nameOfOwl = \"Owlsome\"\nvar numberOfBooksInInventory = 0", index: 1)
        lection_02?.addToLectionTextes(lectionText_21!)
        lection_02?.addToLectionTextes(lectionText_22!)
        lesson_01?.addToLectionList(lection_02!)
        
        let lection_03 = Lection(title: "Type Annotations", index: 2)
        let lectionText_31 = LectionText(isCode: false, text: "In Swift we have lots of different types for variables. The most common types are:\nInt: whole numbers\nDouble: Floating-point number\nString: series of characters\nBool: using one of the Boolean literals true or false", index: 0)
        let lectionText_32 = LectionText(isCode: true, text: "let specialNumber = 42\nlet pi = 3.14159\nlet name = \"Owlsome\"\nlet isAnswerCorrect = true", index: 1)
        let lectionText_33 = LectionText(isCode: false, text: "You can provide a type annotation when you declare a constant or variable, to be clear about the kind of values the constant or variable can store. Write a type annotation by placing a colon after the constant or variable name, followed by a space, followed by the name of the type to use.", index: 2)
        let lectionText_34 = LectionText(isCode: true, text: "var welcomeMessage: String\nwelcomeMessage = \"Hello\"", index: 3)
        lection_03?.addToLectionTextes(lectionText_31!)
        lection_03?.addToLectionTextes(lectionText_32!)
        lection_03?.addToLectionTextes(lectionText_33!)
        lection_03?.addToLectionTextes(lectionText_34!)
        lesson_01?.addToLectionList(lection_03!)
        
        let lection_04 = Lection(title: "Type Casting", index: 3)
        let lectionText_41 = LectionText(isCode: false, text: "It is possible to convert a value into another type, but works only correctly if they are compatible. Otherwise the new value would be nil.", index: 0)
        let lectionText_42 = LectionText(isCode: true, text: "var four = Int(\"4\")\nvar specialNumberAsString = String(42)", index: 1)
        lection_04?.addToLectionTextes(lectionText_41!)
        lection_04?.addToLectionTextes(lectionText_42!)
        lesson_01?.addToLectionList(lection_04!)
        
        let lection_05 = Lection(title: "If Statement", index: 4)
        let lectionText_51 = LectionText(isCode: false, text: "Boolean values are particularly useful when you work with conditional statements such as the if statement. An if statement is used for executing code based on the evaluation of one or more conditions. In its simplest form, the if statement has a single if condition. It executes a set of statements only if that condition is true. With else clauses you can provide an alternative set of statements for situations when the if condition is false. The opening and closing braces are required.", index: 0)
        let lectionText_52 = LectionText(isCode: true, text:"if owlsomeIsHappy {\n    print(\"I'm sooo happy!\")\n} else {\n    print(\"I'm not satisfied\")\n}", index: 1)
        lection_05?.addToLectionTextes(lectionText_51!)
        lection_05?.addToLectionTextes(lectionText_52!)
        lesson_01?.addToLectionList(lection_05!)
        
        let testData_01 = TestData(question: "How many possible values can a Boolean (Bool) have?", startOfAnswer: "A Boolean (Bool) can have")
        let answerDictionary_01 = [
            "2 different possible values\n": true,
            "3 different possible values\n": false,
            "4 different possible values\n": false,
            "0 different possible values\n": false
        ]
        testData_01?.answerDictionary = answerDictionary_01 as NSObject
        lesson_01?.addToTestDataList(testData_01!)
        
        let testData_02 = TestData(question: "Which of the following code lines is NOT valid?", startOfAnswer: "The following code line is NOT valid:\n")
        let answerDictionary_02 = [
            "var d: Double = Double(\"3654,11\")\n": true,
            "var s: String; s = \"Hello world\"\n": false,
            "var b = Bool(6 != 7)\n": false,
            "var i = Int(6 + 14)\n": false
        ]
        testData_02?.answerDictionary = answerDictionary_02 as NSObject
        lesson_01?.addToTestDataList(testData_02!)
        
        let testData_03 = TestData(taskDescription: "First define the constant name of the owl and after that the variable emotion. Then check in an If Statement whether the owl is happy and print an appropriate statements.")
        let codeSnippets = ["let owlName = \"Owlsome\"", "var owlEmotion = \"Happy\"", "if owlEmotion == \"Happy\" {", "    print(\"Owlsome is happy!\")", "} else {", "    print(\"Owlsome is not satisfide\")", "}"]
        let possibleMissingWords = ["let", "var", "print", "if", "else"]
        testData_03?.snippetList = codeSnippets as NSObject
        testData_03?.possibleMissingWordList = possibleMissingWords as NSObject
        lesson_01?.addToTestDataList(testData_03!)
        
        let testData_04 = TestData(taskDescription: "Owlsome is sad if the love scale is lower than 40. Define owlName first and than define the owlsomeLoveScale, which is an Integer and just 10 points high. Check with an if statement if Owlsome is lonely and print an appropriate statement.")
        let codeSnippets_02 = ["let owlName = \"Owlsome\"", "var owlsomeLoveScale: Int = 10", "if owlsomeLoveScale < 40 {", "    print(\"\\(owlName) feels lonely and needs a hug!\")", "} else {", "    print(\"\\(owlName) is not lonely. Great!", "}"]
        let possibleMissingWords_02 = ["Owlsome", "10", "40", "Int", "print"]
        testData_04?.snippetList = codeSnippets_02 as NSObject
        testData_04?.possibleMissingWordList = possibleMissingWords_02 as NSObject
        lesson_01?.addToTestDataList(testData_04!)
        
        do {
            try lesson_01?.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't create Lection_01: ", error)
        }
    }
    
    private static func preloadLesson_02() {
        let lesson_02 = Lesson(name: "Collection Types", imageName: "collectionTypes", intendedNumberOfExercises: 2)
        let lection_01 = Lection(title: "Welcome to the second lection", index: 0)
        let lectionText_11 = LectionText(isCode: false, text: "Swift provides 3 primary collection types:\n- Arrays (ordered)\n- Sets (unordered)\n- Dictionaries (unordered key-value associations)\n\nThey are always clear about the types of values and keys that they can store. You cannot insert a value of the wrong type.", index: 0)
        let lectionText_12 = LectionText(isCode: true, text: "var initList = [Int]()\nvar setOfWords = Set<String>()\nvar translateLanguageDictionary = [String: String]\n", index: 1)
        lection_01?.addToLectionTextes(lectionText_11!)
        lection_01?.addToLectionTextes(lectionText_12!)
        lesson_02?.addToLectionList(lection_01!)
        
        let lection_02 = Lection(title: "Arrays", index: 1)
        let lectionText_21 = LectionText(isCode: false, text: "You can initialize an empty array with a pair of square brackets. Than you have to declare the type of the values inside. But you can also write one or more values as an array collection. In this case, you can define the types but you don't  have to.", index: 0)
        let lectionText_22 = LectionText(isCode: true, text: "var shoppingList: [String] = [\"Eggs\", \"Milk\"]\nvar shoppingList = [\"Eggs\", \"Milk\"]", index: 1)
        let lectionText_23 = LectionText(isCode: false, text: "You can add multiple or single values to an array by calling the array's append method. You can also remove an item at a specified index by calling the remove(at:) method.", index: 2)
        let lectionText_24 = LectionText(isCode: true, text: "shoppingList += \"Chocolate\"\nshoppingList += \"Cheese\", \"Butter\"\nshoppingList.remove(at: 0)\n", index: 3)
        let lectionText_25 = LectionText(isCode: false, text:"You can retrieve a value of a specified index by using subscript syntax, passing the index within squre brackets immediately after the name of the array.", index: 4)
        let lectionText_26 = LectionText(isCode: true, text:"var firstElement = shoppingList[0]", index: 5)
        lection_02?.addToLectionTextes(lectionText_21!)
        lection_02?.addToLectionTextes(lectionText_22!)
        lection_02?.addToLectionTextes(lectionText_23!)
        lection_02?.addToLectionTextes(lectionText_24!)
        lection_02?.addToLectionTextes(lectionText_25!)
        lection_02?.addToLectionTextes(lectionText_26!)
        lesson_02?.addToLectionList(lection_02!)
        
        let lection_03 = Lection(title: "Sets", index: 2)
        let lectionText_31 = LectionText(isCode: false, text: "The type of a Swift set is written as Set<Element>, where Element is the type that the set is allowed to store. Unlike arrays, sets do not have an equivalent shorthand form or. The syntax of the arrays and sets is similar, that's why you need to define set as type. But you can handle value changes the same way as arrays.", index: 0)
        let lectionText_32 = LectionText(isCode: true, text: "var letters = Set<Character>()\nletters.insert(\"a\")\nletters = []\n\nvar genres: Set = [\"Rock\", \"Jazz\"]", index: 1)
        let lectionText_33 = LectionText(isCode: false, text: "To check whether a set contains a particular item, use the contains(_:) method.", index: 2)
        let lectionText_34 = LectionText(isCode: true, text: "if genres.contains(\"Funk\") {\n    print(\"set contains funk\")\n}", index: 3)
        lection_03?.addToLectionTextes(lectionText_31!)
        lection_03?.addToLectionTextes(lectionText_32!)
        lection_03?.addToLectionTextes(lectionText_33!)
        lection_03?.addToLectionTextes(lectionText_34!)
        lesson_02?.addToLectionList(lection_03!)
        
        let lection_04 = Lection(title: "Dictionaries", index: 3)
        let lectionText_41 = LectionText(isCode: false, text: "A dictionary stores associations between keys of the same type and values of the same type in a collection with no defined ordering. Each value is associated with a unique key, which acts as an identifier for that value within the dictionary. You use them when you need to look up values based on their identifier.", index: 0)
        let lectionText_42 = LectionText(isCode: true, text: "var namesOfIntegers_1 = [Int: String]()\nvar namesOfIntegers_2 = [1: \"one\", 2: \"two\"]", index: 1)
        let lectionText_43 = LectionText(isCode: false, text: "To add or update the value of a key, you can use subscript syntax.", index: 2)
        let lectionText_44 = LectionText(isCode: true, text: "namesOfIntegers_2[3] = \"three\"\nnamesOfIntegers_2[1] = \"eins\"", index: 3)
        let lectionText_45 = LectionText(isCode: false, text: "You can use subscript syntax to remove a key-value pair from a dictionary by assigning a value of nil for that key.", index: 4)
        let lectionText_46 = LectionText(isCode: true, text: "namesOfIntegers_2[1] = nil", index: 5)
        lection_04?.addToLectionTextes(lectionText_41!)
        lection_04?.addToLectionTextes(lectionText_42!)
        lection_04?.addToLectionTextes(lectionText_43!)
        lection_04?.addToLectionTextes(lectionText_44!)
        lection_04?.addToLectionTextes(lectionText_45!)
        lection_04?.addToLectionTextes(lectionText_46!)
        lesson_02?.addToLectionList(lection_04!)
        
        let testData_01 = TestData(question: "Which of the following codes creates an set with integer?", startOfAnswer: "The following code creates a new set with integer: \n")
        let answerDictionary_01 = [
            "var numbers = Set<Int>()\n": true,
            "var numbers = Set<Int>[]\n": false,
            "var numbers = [1, 2, 3]\n": false,
            "var numbers = [1: 2]\n": false
        ]
        testData_01?.answerDictionary = answerDictionary_01 as NSObject
        lesson_02?.addToTestDataList(testData_01!)
        
        let testData_02 = TestData(taskDescription: "Add to a dictionary with integer as keys and strings as values the pair 3: \"threeeee\". Then change the value of 3 to \"three\" and than remove the pair from the dictionary.")
        let codeSnippets_02 = ["var dict: [Int: String]", "dict[3] = \"threeee\"", "dict[3] = \"three\"", "dict[3] = nil"]
        let possibleMissingWords_02 = ["3", "nil", "Int"]
        testData_02?.snippetList = codeSnippets_02 as NSObject
        testData_02?.possibleMissingWordList = possibleMissingWords_02 as NSObject
        lesson_02?.addToTestDataList(testData_02!)
        
        do {
            try lesson_02?.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't create Lection_02: ", error)
        }
    }
    
    private static func preloadLesson_03() {
        let lesson_03 = Lesson(name: "Control Flow", imageName: "controlFlow", intendedNumberOfExercises: 2)
        
        let lection_01 = Lection(title: "We need control", index: 0)
        let lectionText_11 = LectionText(isCode: false, text: "Swift provides a veriety of control flow statements. You already know something about conditional statements like if but there are even more. Control flow statements include for example\n\n - switch statements to execute different branches of code based on certain conditions\n\n- for-in loops that makes it easy to iterate over arrays, dictionaries, ranges, strings and other sequences.", index: 0)
        lection_01?.addToLectionTextes(lectionText_11!)
        lesson_03?.addToLectionList(lection_01!)
        
        let lection_02 = Lection(title: "Switch cases", index: 1)
        let lectionText_21 = LectionText(isCode: false, text: "A switch statement considers a value and compares it against several possible matching patterns. It then executes an appropriate block of code, based on the first pattern that matches successfully. This statement provides an alternative to the if statement for responding to multiple potential states. The following code prints the line \"The last letter of the alphabet\"", index: 0)
        let lectionText_22 = LectionText(isCode: true, text: "let someCharacter: Character = \"z\"\nswitch someCharacter {\ncase \"a\":\n    print(\"The first letter of the alphabet\")\ncase \"z\":\n    print(\"The last letter of the alphabet\")\ndefault:\n    print(\"Some other character\")", index: 1)
        let lectionText_23 = LectionText(isCode: false, text: "The body of each case must contain at least one executable statement. You can combine multiple values into a compound case, separating the values with commas.", index: 2)
        let lectionText_24 = LectionText(isCode: true, text: "let character2: Character = \"a\"\nswitch character2 {\ncase \"a\", \"A\":\n    print(\"The letter A\")\ndefault:\n    print(\"Not the letter A\")\n}", index: 3)
        lection_02?.addToLectionTextes(lectionText_21!)
        lection_02?.addToLectionTextes(lectionText_22!)
        lection_02?.addToLectionTextes(lectionText_23!)
        lection_02?.addToLectionTextes(lectionText_24!)
        lesson_03?.addToLectionList(lection_02!)

        let lection_03 = Lection(title: "For-in loops", index: 2)
        let lectionText_31 = LectionText(isCode: false, text: "You use the for-in loop to iterate over a sequence, such as items in an array, ranges of numbers, or characters in a string.\nThis example uses a for-in loop to iterate over the items in an array.", index: 0)
        let lectionText_32 = LectionText(isCode: true, text: "let names = [\"Anna\", \"Brian\", \"Jack\"]\nfor name in names {\n    print(\"Hello, \\(name)!\")\n}\n// Hello, Anna!\n// Hello, Brian!  \n// Hello, Jack!", index: 1)
        let lectionText_33 = LectionText(isCode: false, text: "Break ends the loop’s execution immediately and transfers control to the code after the loop’s closing brace (}). No further code from the current iteration of the loop is executed, and no further iterations of the loop are started.", index: 2)
        let lectionText_34 = LectionText(isCode: true, text: "for name in names {\n    if (name == \"Brian\") {\n        break\n    }\n    print(\"Hello, \\(name)!\")\n}\n// Hello, Anna!", index: 3)
        lection_03?.addToLectionTextes(lectionText_31!)
        lection_03?.addToLectionTextes(lectionText_32!)
        lection_03?.addToLectionTextes(lectionText_33!)
        lection_03?.addToLectionTextes(lectionText_34!)
        lesson_03?.addToLectionList(lection_03!)
        
        let testData_01 = TestData(question: "What is the output of the following code snippet?\nlet emotions = [\"happy\", \"angry\", \"sad\"]\nfor emotion in emotions {\n    if (emotion == \"angry\") {\n        print(\"You need to feed Owlsome!\")\n        break\n    }\n    print(\"Owlsome is \\(emotion)!\")\n}\n", startOfAnswer: "The output of\nlet emotions = [\"happy\", \"angry\", \"sad\"]\nfor emotion in emotions {\n    if (emotion == \"angry\") {\n        print(\"You need to feed Owlsome!\")\n        break\n    }\n    print(\"Owlsome is \\(emotion)!\")\n}\n is: \n")
        let answerDictionary_01 = [
            "Owlsome is happy! You need to feed Owlsome!\n": true,
            "Owlsome is happy! You need to feed Owlsome! Owlsome is angry!\n": false,
            "Owlsome is happy! Owlsome is angry! Owlsome is sad!\n": false,
            "Owlsome is sad! Owlsome needs a hug!\n": false
        ]
        testData_01?.answerDictionary = answerDictionary_01 as NSObject
        lesson_03?.addToTestDataList(testData_01!)
        
        let testData_02 = TestData(taskDescription: "Define a constant array called names with the values \"Owlsome\", \"Owly\" and \"Knowl\". Then iterate over the array and print the items.")
        let codeSnippets_02 = ["let names = [\"Owlsome\", \"Owly\", \"Knowl\"]", "for name in names {", "    print(name)", "}"]
        let possibleMissingWords_02 = ["names", "Owlsome", "for", "print"]
        testData_02?.snippetList = codeSnippets_02 as NSObject
        testData_02?.possibleMissingWordList = possibleMissingWords_02 as NSObject
        lesson_03?.addToTestDataList(testData_02!)
        
        do {
            try lesson_03?.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't create Lection_03: ", error)
        }
    }
    
    private static func preloadLesson_04() {
           let lesson_04 = Lesson(name: "Functions", imageName: "functions", intendedNumberOfExercises: 3)
           
           let lection_01 = Lection(title: "Introduction to functions", index: 0)
           let lectionText_11 = LectionText(isCode: false, text: "A function typically consists of a function name, input parameters, a return type and a function block, in which you can declare what your function will do. The following sayHi function will take a owl's name and and greet it. ", index: 0)
           let lectionText_12 = LectionText(isCode: true, text: "func sayHi(owl: String) -> String {\n    let greeting = \"Hi, \" + owl + \"!\"\n    return greeting\n}", index: 1)
           let lectionText_13 = LectionText(isCode: false, text: "You can call the function and pass arguments that match the types of the function’s parameters.", index: 2)
           let lectionText_14 = LectionText(isCode: true, text: "print(sayHi(owl: \"Owlsome\"))\n// prints \"Hi, Owlsome!\"", index: 3)
           lection_01?.addToLectionTextes(lectionText_11!)
           lection_01?.addToLectionTextes(lectionText_12!)
           lection_01?.addToLectionTextes(lectionText_13!)
           lection_01?.addToLectionTextes(lectionText_14!)
           lesson_04?.addToLectionList(lection_01!)
           
           let lection_02 = Lection(title: "Functions and Parameters", index: 1)
           let lectionText_21 = LectionText(isCode: false, text: "A function can have no input parameters…", index: 0)
           let lectionText_22 = LectionText(isCode: true, text: "func sayHi() -> String {\n    return \"Hi, Owlsome!\"\n}", index: 1)
           let lectionText_23 = LectionText(isCode: false, text: "... or multiple input parameters.", index: 2)
           let lectionText_24 = LectionText(isCode: true, text: "func sayHi(owl: String, alreadyGreeted: Bool) -> String {\n    if alreadyGreeted {\n        return greetAgain(owl: owl)\n    } else {\n        return greet(owl: owl)\n    }\n}\nprint(sayHi(owl: \"Owlsome\", alreadyGreeted: true))", index: 3)
           lection_02?.addToLectionTextes(lectionText_21!)
           lection_02?.addToLectionTextes(lectionText_22!)
           lection_02?.addToLectionTextes(lectionText_23!)
           lection_02?.addToLectionTextes(lectionText_24!)
           lesson_04?.addToLectionList(lection_02!)
           
           let lection_03 = Lection(title: "Functions and Return Values", index: 2)
           let lectionText_31 = LectionText(isCode: false, text: "A function does not require a return type.", index: 0)
           let lectionText_32 = LectionText(isCode: true, text: "func sayHi(owl: String) {\n    print(\"Hello, \\(owl)!\")\n}\nsayHi(owl: \"Owlsome\")", index: 1)
           let lectionText_33 = LectionText(isCode: false, text: "It can have multiple return values as well. You can use a tuple type as the return type for a function to return multiple values as part of one compound return value.", index: 2)
           let lectionText_34 = LectionText(isCode: true, text: "func minMax(array: [Int]) -> (min: Int, max: Int) {\n    //some code\n    return (min, max)\n}", index: 3)
           lection_03?.addToLectionTextes(lectionText_31!)
           lection_03?.addToLectionTextes(lectionText_32!)
           lection_03?.addToLectionTextes(lectionText_33!)
           lection_03?.addToLectionTextes(lectionText_34!)
           lesson_04?.addToLectionList(lection_03!)
    
           
           let testData_01 = TestData(question: "Which of the following statements is true?\n A function...", startOfAnswer: "A function ")
           let answerDictionary_01 = [
               "can only have 1 return value\n": false,
               "must have a return type\n": false,
               "can have multiple arguments\n": true,
               "can have input parameters without any types\n": false
           ]
           testData_01?.answerDictionary = answerDictionary_01 as NSObject
           lesson_04?.addToTestDataList(testData_01!)
           
           let testData_02 = TestData(question: "Which of the following code lines is NOT valid?", startOfAnswer: "The following code line is NOT valid:\n")
           let answerDictionary_02 = [
               "func hi(owl: String) -> Int {\n    return \"Hi \"+ owl\n}": true,
               "func hi() -> String {\n    return \"Hi\"\n}": false,
               "func getName(owl: String) -> String {\n    return owl\n}": false,
               "func printOwlsome () {\n    print (\"Owlsome\")\n}": false
           ]
           testData_02?.answerDictionary = answerDictionary_02 as NSObject
           lesson_04?.addToTestDataList(testData_02!)
           
           let testData_03 = TestData(taskDescription: "First define a function that adds the amount to a counter variable. The second function should reset this counter back to its initial value.")
           let codeSnippets = ["func increment(byAmount amount: Int) {", "    count += amount", "}", "func reset(toCount count: Int) {", "    self.count = count ", "}"]
           let possibleMissingWords = ["func", "amount"]
           testData_03?.snippetList = codeSnippets as NSObject
           testData_03?.possibleMissingWordList = possibleMissingWords as NSObject
           lesson_04?.addToTestDataList(testData_03!)
           
           do {
               try lesson_04?.managedObjectContext?.save()
           } catch let error as NSError {
               print("Error: Couldn't create Lection_04: ", error)
           }
       }
    private static func preloadLesson_05() {
           let lesson_05 = Lesson(name: "Classes", imageName: "classes", intendedNumberOfExercises: 4)
           
           let lection_01 = Lection(title: "Introduction to classes", index: 0)
           let lectionText_11 = LectionText(isCode: false, text: "You can define a class with the keyword class and the classname using UpperCamelCase.", index: 0)
           let lectionText_12 = LectionText(isCode: true, text: "class Owl {\n    //class definition goes here\n}", index: 1)
           let lectionText_13 = LectionText(isCode: false, text: "A class can have properties, initializers and methods.", index: 2)
           let lectionText_14 = LectionText(isCode: true, text: "class Owl {\n    //properties\n    //initializers\n    //methods\n}", index: 3)
           let lectionText_15 = LectionText(isCode: false, text: "You can create an instance of a class by assigning it to a variable.", index: 4)
           let lectionText_16 = LectionText(isCode: true, text: "let someOwl = Owl()", index: 5)
           lection_01?.addToLectionTextes(lectionText_11!)
           lection_01?.addToLectionTextes(lectionText_12!)
           lection_01?.addToLectionTextes(lectionText_13!)
           lection_01?.addToLectionTextes(lectionText_14!)
           lection_01?.addToLectionTextes(lectionText_15!)
           lection_01?.addToLectionTextes(lectionText_16!)
           lesson_05?.addToLectionList(lection_01!)
           
           let lection_02 = Lection(title: "Properties I", index: 1)
           let lectionText_21 = LectionText(isCode: false, text: "A class can contain properties.", index: 0)
           let lectionText_22 = LectionText(isCode: true, text: "class Owl {\n    var name= \"Owlsome\"\n    var isClever = true\n}", index: 1)
           let lectionText_23 = LectionText(isCode: false, text: "You can access a property of an instance using dot syntax.", index: 2)
           let lectionText_24 = LectionText(isCode: true, text: "print(\"The owls name is \\(someOwl.name)\")\n// Prints \"The owls name is Owlsome\"", index: 3)
           let lectionText_25 = LectionText(isCode: false, text: "If you want to assign a value to a property you can achieve it by following this syntax:", index: 4)
           let lectionText_26 = LectionText(isCode: true, text: "someOwl.name = \"Hedwig\"", index: 5)
           lection_02?.addToLectionTextes(lectionText_21!)
           lection_02?.addToLectionTextes(lectionText_22!)
           lection_02?.addToLectionTextes(lectionText_23!)
           lection_02?.addToLectionTextes(lectionText_24!)
           lection_02?.addToLectionTextes(lectionText_25!)
           lection_02?.addToLectionTextes(lectionText_26!)
           lesson_05?.addToLectionList(lection_02!)
           
           let lection_03 = Lection(title: "Properties II", index: 2)
           let lectionText_31 = LectionText(isCode: false, text: "There are two types of properties: Stored properties and computed properties.", index: 0)
           let lectionText_32 = LectionText(isCode: false, text: "A stored property is a constant or variable that is stored as part of an instance of a particular class or structure. ", index: 1)
           let lectionText_33 = LectionText(isCode: false, text: "A computed property does not actually store a value. Instead, it provides a getter and an optional setter to retrieve and set other properties and values indirectly.", index: 2)
           let lectionText_34 = LectionText(isCode: true, text: "class Owl {\n    //Stored Property\n    var isClever = true\n    //Computed Property\n    var description: String{\n        get{\n            return \"Cleverness: \" + isClever\n        }\n    }\n}", index: 3)
           lection_03?.addToLectionTextes(lectionText_31!)
           lection_03?.addToLectionTextes(lectionText_32!)
           lection_03?.addToLectionTextes(lectionText_33!)
           lection_03?.addToLectionTextes(lectionText_34!)
           lesson_05?.addToLectionList(lection_03!)
           
           let lection_04 = Lection(title: "Methods", index: 3)
           let lectionText_41 = LectionText(isCode: false, text: "Instance methods are functions that belong to instances of a particular class, structure, or enumeration. They support the functionality of those instances, either by providing ways to access and modify instance properties, or by providing functionality related to the instance’s purpose. Instance methods have exactly the same syntax as functions, as described in the lesson Functions.", index: 0)
           let lectionText_42 = LectionText(isCode: true, text: "class Counter {\n    var owlCount = 0\n     func increment() {\n        count += 1\n    }\n}", index: 1)
           let lectionText_43 = LectionText(isCode: false, text: "You call instance methods with the same dot syntax as properties:", index: 2)
           let lectionText_44 = LectionText(isCode: true, text: "let counter = Counter()\ncounter.increment()", index: 3)
           let lectionText_45 = LectionText(isCode: false, text: "You use the self property to refer to the current instance within its own instance methods. The increment() method in the example above could have been written like this:", index: 4)
           let lectionText_46 = LectionText(isCode: true, text: "func increment() {\n    self.count += 1\n}", index: 5)
           lection_04?.addToLectionTextes(lectionText_41!)
           lection_04?.addToLectionTextes(lectionText_42!)
           lection_04?.addToLectionTextes(lectionText_43!)
           lection_04?.addToLectionTextes(lectionText_44!)
           lection_04?.addToLectionTextes(lectionText_45!)
           lection_04?.addToLectionTextes(lectionText_46!)
           lesson_05?.addToLectionList(lection_04!)
           
           let lection_05 = Lection(title: "Initializer", index: 4)
           let lectionText_51 = LectionText(isCode: false, text: "Initializers are called to create a new instance of a particular type. You can define them by using the init keyword.", index: 0)
           let lectionText_52 = LectionText(isCode: true, text: "class Owl {\n    var name: String\n    init() {\n         name = \"Owlsome\"\n    }\n}\nvar owl = Owl()", index: 1)
           let lectionText_53 = LectionText(isCode: false, text: "You can provide initialization parameters as part of an initializer’s definition, to define the types and names of values that customize the initialization process. Initialization parameters have the same capabilities and syntax as function and method parameters.", index: 2)
           let lectionText_54 = LectionText(isCode: true, text: "class Owl {\n    var name: String\n    init(name: String) {\n        self.name = name\n    }\n}\nvar owl = Owl(name: \"Owlsome\")", index: 3)
           lection_05?.addToLectionTextes(lectionText_51!)
           lection_05?.addToLectionTextes(lectionText_52!)
           lection_05?.addToLectionTextes(lectionText_53!)
           lection_05?.addToLectionTextes(lectionText_54!)
           lesson_05?.addToLectionList(lection_05!)
           
           let lection_06 = Lection(title: "Inheritance", index: 5)
           let lectionText_61 = LectionText(isCode: false, text: "A class can inherit from another class that is called base class. In the following example defines the class Owl which inherits methods and properties from its base class bird.", index: 0)
           let lectionText_62 = LectionText(isCode: true, text: "class Owl: Bird{}", index: 1)
           lection_06?.addToLectionTextes(lectionText_61!)
           lection_06?.addToLectionTextes(lectionText_62!)
           lesson_05?.addToLectionList(lection_06!)
           
           let lection_07 = Lection(title: "Overriding", index: 6)
           let lectionText_71 = LectionText(isCode: false, text: "You can override the initializer and properties from your base class.", index: 0)
           let lectionText_72 = LectionText(isCode: true, text: "class Owl: Bird {\n    override init() {\n        super.init()\n        name = \"Owlsome\"\n    }\n}", index: 1)
           lection_07?.addToLectionTextes(lectionText_71!)
           lection_07?.addToLectionTextes(lectionText_72!)
           lesson_05?.addToLectionList(lection_07!)
    
           
           let testData_01 = TestData(question: "How do you access a property of a class?", startOfAnswer: "You can access a poperty of a class by typing: \n")
           let answerDictionary_01 = [
               "car.speed": true,
               "car>speed": false,
               "car?speed": false,
               "car:speed": false
           ]
           testData_01?.answerDictionary = answerDictionary_01 as NSObject
           lesson_05?.addToTestDataList(testData_01!)
           
           let testData_02 = TestData(question: "What is NOT typically inside the code block of a class?", startOfAnswer: "The following is NOT typically inside the code block of a class:\n")
           let answerDictionary_02 = [
               "Properties": false,
               "Methods": false,
               "Initializers": false,
               "Base Class": true
           ]
           testData_02?.answerDictionary = answerDictionary_02 as NSObject
           lesson_05?.addToTestDataList(testData_02!)
           
           let testData_03 = TestData(taskDescription: "Override the property description in this subclass.")
           let codeSnippets = ["class Car: Vehicle {", "    override var description: String {", "        return super.description + \", \\(speed) mph\"", "    }", "}"]
           let possibleMissingWords = ["class", "override", "super", "description"]
           testData_03?.snippetList = codeSnippets as NSObject
           testData_03?.possibleMissingWordList = possibleMissingWords as NSObject
           lesson_05?.addToTestDataList(testData_03!)
           
           let testData_04 = TestData(question: "How do you let a class inherit from a base class in Swift?", startOfAnswer: "The following code line lets the class Bicycle inherit from Verhicle:\n")
           let answerDictionary_04 = [
               "class Bicycle: Vehicle{}": true,
               "class Bicycle extends Vehicle{}": false,
               "class Bicycle (Vehicle)": false,
               "class Bicycle: Vehicle()": false
           ]
           testData_04?.answerDictionary = answerDictionary_04 as NSObject
           lesson_05?.addToTestDataList(testData_04!)
           
           let testData_05 = TestData(taskDescription: "Define a class Vehicle and give it a stored property for the number of wheels and a computed property for the description.")
           let codeSnippets_05 = ["class Vehicle {", "    var numberOfWheels = 0", "    var description: String {", "        return \"\\(numberOfWheels) wheels\"", "    }", "}"]
           let possibleMissingWords_05 = ["class", "Vehicle", "String", "description"]
           testData_05?.snippetList = codeSnippets_05 as NSObject
           testData_05?.possibleMissingWordList = possibleMissingWords_05 as NSObject
           lesson_05?.addToTestDataList(testData_05!)
           
           let testData_06 = TestData(taskDescription: "Override the constructor of the class called \"Vehicle\" and assign in the initializer the number of wheels to 2. Then create a instance of Bicycle and print the number of wheels. ")
           let codeSnippets_06 = ["class Bicycle: Vehicle {", "    override init() {", "        super.init()", "        numberOfWheels = 2", "    }", "}", "let myBicycle = Bicycle()", "print(myBicycle.numberOfWheels)"]
           let possibleMissingWords_06 = ["class", "super", "override", "Vehicle", "print", "init"]
           testData_06?.snippetList = codeSnippets_06 as NSObject
           testData_06?.possibleMissingWordList = possibleMissingWords_06 as NSObject
           lesson_05?.addToTestDataList(testData_06!)
           
           do {
               try lesson_05?.managedObjectContext?.save()
           } catch let error as NSError {
               print("Error: Couldn't create Lection_05: ", error)
           }
       }

}
