//
//  MasterTestViewController.swift
//  Knowledge
//
//  Created by FMA1 on 13.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit
import CoreData

/**
 MasterTestViewController shows current test exercise
 */
class MasterTestViewController: UIViewController {
    
    var lesson: Lesson?
    var currentTest: TestExercise?
    var currentTestIndex: Int? {
        didSet {
            currentTest = lesson!.currentTestExercises![currentTestIndex!]
            navigationItem.title = "\"\(lesson!.name!)\" - \(currentTestIndex! + 1)/ \(lesson!.currentTestExercises!.count)"
            setUpView()
        }
    }
    
     // MARK: - ViewController for different test types
    lazy var quizTestViewController : QuizTestViewController = {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        var viewController = storyboard.instantiateViewController(withIdentifier: "QuizTestViewController") as! QuizTestViewController
        self.addViewController(asChildViewController: viewController)
        return viewController
    }()
    
    lazy var trueOrFalseTestViewController : TrueOrFalseTestViewController = {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        var viewController = storyboard.instantiateViewController(withIdentifier: "TrueOrFalseTestViewController") as! TrueOrFalseTestViewController
        self.addViewController(asChildViewController: viewController)
        return viewController
    }()
    
    lazy var sortSnippetTestViewController : SortSnippetTestViewController = {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        var viewController = storyboard.instantiateViewController(withIdentifier: "SortSnippetTestViewController") as! SortSnippetTestViewController
        self.addViewController(asChildViewController: viewController)
        return viewController
    }()
    
    lazy var clozeTestViewController : ClozeTestViewController = {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        var viewController = storyboard.instantiateViewController(withIdentifier: "ClozeTestViewController") as! ClozeTestViewController
        self.addViewController(asChildViewController: viewController)
        return viewController
    }()
    
    lazy var evaluationController : EvaluationViewController = {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        var viewController = storyboard.instantiateViewController(withIdentifier: "EvaluationViewController") as! EvaluationViewController
        self.addViewController(asChildViewController: viewController)
        return viewController
    }()
    
    let testDescriptionDictionary: [TestType: String] = [
        .quiz : "Answer the question !",
        .trueOrFalse: "Is it true or false ?",
        .sortSnippets: "Sort the code snippets by drag and drop.",
        .cloze: "Complete the code by adding words."
    ]

    override func viewWillAppear(_ animated: Bool) {
        var testIndex = 0
        // It's possible to continue a test (checks which is the first not solved test)
        for test in lesson!.currentTestExercises! {
            if !test.solved {
                currentTestIndex = testIndex
                break
            }
            testIndex += 1
        }
    }
    
    private func setUpView() {
        print("-----")        
        hideAllViews()
        print("Aktuelle Aufgabe: ", currentTest!.testTypeEnum)
        switch currentTest!.testTypeEnum {
        case .quiz:
            quizTestViewController.testDescription = testDescriptionDictionary[.quiz]
            quizTestViewController.testExercise = currentTest
            quizTestViewController.parentVC = self
            quizTestViewController.view.isHidden = false
        case .trueOrFalse:
            trueOrFalseTestViewController.testDescription = testDescriptionDictionary[.trueOrFalse]
            trueOrFalseTestViewController.testExercise = currentTest
            trueOrFalseTestViewController.parentVC = self
            trueOrFalseTestViewController.view.isHidden = false
        case .sortSnippets:
            sortSnippetTestViewController.testDescription = testDescriptionDictionary[.sortSnippets]
            sortSnippetTestViewController.testExercise = currentTest
            sortSnippetTestViewController.parentVC = self
            sortSnippetTestViewController.view.isHidden = false
        case .cloze:
            clozeTestViewController.testDescription = testDescriptionDictionary[.cloze]
            clozeTestViewController.testExercise = currentTest
            clozeTestViewController.parentVC = self
            clozeTestViewController.view.isHidden = false
        }
    }

    private func hideAllViews() {
        quizTestViewController.view.isHidden = true
        trueOrFalseTestViewController.view.isHidden = true
        sortSnippetTestViewController.view.isHidden = true
        clozeTestViewController.view.isHidden = true
    }
    
    private func addViewController(asChildViewController childViewController: UIViewController){
        addChild(childViewController)
        view.addSubview(childViewController.view)
        childViewController.view.frame = view.bounds
        childViewController.view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        childViewController.didMove(toParent: self)
    }
    
    private func removeViewController(viewController: UIViewController) {
        viewController.willMove(toParent: nil)
        viewController.view.removeFromSuperview()
        viewController.removeFromParent()
    }
    
    func nextTest() {
        if currentTestIndex! + 1 < lesson!.currentTestExercises!.count {
            currentTestIndex! += 1
        } else {
            // Show Evaluation Screen
            navigationItem.title = "Test passed"
            setUpView()
            evaluationController.lesson = lesson
            evaluationController.testExercises = lesson!.currentTestExercises
            evaluationController.parentVC = self
            evaluationController.view.isHidden = false
            setUpView()
        }
    }
    
    func resolvedExercise(correct: Bool) {
        do {
            try lesson?.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't save lesson with solved Test: ", error)
        }
    }
    
}
