//
//  EvaluationViewController.swift
//  Knowledge
//
//  Created by FMA1 on 15.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit
import CoreData

/**
EvaluationViewController for test type quiz
*/
class EvaluationViewController: UIViewController {

    var lesson: Lesson?
    var testExercises: [TestExercise]? {
        didSet {
            evaluateTests()
        }
    }
    var book: Book? {
        didSet {
            bookImage!.image = UIImage(named: book!.imageName)
        }
    }
    
    var parentVC: MasterTestViewController?
    private let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    private var owl: Owl?
    
    @IBOutlet weak var learnedSomethingLabel: UILabel!
    @IBOutlet weak var correctExercisesLabel: UILabel!
    @IBOutlet weak var bookImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let context = container?.viewContext
        let fetchRequest = NSFetchRequest<Owl>(entityName: "Owl")
        do {
            let response = try context?.fetch(fetchRequest)
            owl = response?[0]
        } catch let error as NSError {
            print("Failed to fetch owl: ", error)
        }
    }
    
    private func evaluateTests() {
        let numberOfCorrectSolvedTests = checkCorrectTests()
        var pointsForReachedPoints = 0
        let percentageOfCorrectAnswers = calculatePercentageOfCorrectSolvedTests(numberOfCorrectSolvedTests: numberOfCorrectSolvedTests, testCount: testExercises!.count)
        correctExercisesLabel!.text = "You have \(numberOfCorrectSolvedTests)/\(testExercises!.count) right !"
        
        // First time of correct solving
        if numberOfCorrectSolvedTests == testExercises!.count && !lesson!.atLeastOneTestSerieSolvedCorrectly {
            pointsForReachedPoints += 1
            learnedSomethingLabel.isHidden = false
            learnedSomethingLabel!.text = "Owlsome learned something new !\nYou earned points for that."
            lesson!.atLeastOneTestSerieSolvedCorrectly = true
        } else {
            learnedSomethingLabel.isHidden = true
        }
        saveTestResult()
        addBookAndPointsToOwlsome(percentageOfCorrectAnswers: percentageOfCorrectAnswers, pointsForReachedPoints: pointsForReachedPoints)
    }
    
    private func addBookAndPointsToOwlsome(percentageOfCorrectAnswers: Double, pointsForReachedPoints: Int) {
        do {
            owl?.reachedPoints += pointsForReachedPoints
            let pointsOfBook = Book.getPoints(by: percentageOfCorrectAnswers)
            let colorOfBook = Book.getImageName(by: percentageOfCorrectAnswers)
            book = Book(points: pointsOfBook, imageName: colorOfBook)
            owl?.addToBookList(book!)
            owl?.lastSolvedTestTimestamp = Date()
            try owl!.managedObjectContext?.save()
        } catch let error as NSError {
            print("Failed to save owl: ", error)
        }
    }
    
    private func saveTestResult() {
        do {
            try lesson!.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't save atLeastOneTestSerieSolvedCorrectly in lesson", error)
        }
    }

    private func calculatePercentageOfCorrectSolvedTests(numberOfCorrectSolvedTests: Int, testCount: Int) -> Double {
        return numberOfCorrectSolvedTests != 0 ? (100.0 / Double(testExercises!.count)) * Double(numberOfCorrectSolvedTests) : 0
    }
    
    // Returns count of correct solved tests
    private func checkCorrectTests() -> Int {
        var correctSolvedTests = 0
        for test in testExercises! {
            if test.solvedCorrect {
                correctSolvedTests += 1
            }
        }
        return correctSolvedTests
    }
    
    func createNewTests(for lesson: Lesson) {
        let tests = generateTestExercises(for: lesson)
        for test in tests {
            lesson.addToCurrentTestExerciseList(test)
        }
        do {
            try lesson.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't save lesson with tests: ", error)
        }
    }

    
}
