//
//  ClozeTestViewController.swift
//  Knowledge
//
//  Created by FMA1 on 13.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
ClozeTestViewController for test type quiz
*/
class ClozeTestViewController: UIViewController, UITableViewDataSource , UITableViewDelegate, UIScrollViewDelegate {
    
    // Cloze test
    var testExercise: TestExercise? {
        didSet {
            testDescriptionLabel?.text = testDescription ?? ""
            testData = (testExercise!.testData.returnAsTestDataObject() as! SnippetTestData)
            testDetailDescriptionLabel.text = testData!.taskDescription
            createTableViewCells()
            tableView.reloadData()
        }
    }
    
    var testData: SnippetTestData?
    var testDescription: String?
    var parentVC: MasterTestViewController?
    var tableViewCells = [ClozeTableViewCell]()

    
    @IBOutlet weak var testDescriptionLabel: UILabel!
    @IBOutlet weak var testDetailDescriptionLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var evaluateButton: UIButton!
    @IBOutlet weak var continueButton: UIButton!
    
    // Set layout
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate = self
        view.backgroundColor = .white
        tableView.register(ClozeTableViewCell.self, forCellReuseIdentifier: "ClozeTableViewCell")
        tableView.contentInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: -10)
        tableView.alwaysBounceHorizontal = false
        tableView.contentSize = CGSize(width: self.tableView.frame.size.width, height: self.tableView.contentSize.height)
        tableView.autoresizesSubviews = true
        // Handling keyboard for textfields
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(sender:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(sender:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    // Hide continueButton (only evaluation button is shown)
    override func viewWillAppear(_ animated: Bool) {
        continueButton.isHidden = true
        evaluateButton.isHidden = false
    }
    
    // Set cells for tableView
    func createTableViewCells() {
        let clozeSnippets = replaceSpecialWords(withUnderlines: true)
        let cellStrings = createSnippetArray(of: clozeSnippets)
        var index = 0
        for cellString in cellStrings {
            let cell = ClozeTableViewCell()
            cell.setup(values: cellString)
            index += 1
            tableViewCells.append(cell)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableViewCells.count
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .none
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return tableViewCells[indexPath.row]
    }
    
    // Cell input with solution
    @IBAction func evaluateTest(_ sender: UIButton) {
        tableView.reloadData()
        let rowsCount = self.tableView.numberOfRows(inSection: 0)
        var solvedCorrect = true
        testExercise?.solved = true
        for i in 0..<rowsCount  {
            let cell = tableViewCells[i]
            // Evaluate cell content
            if testData!.snippets[i] == cell.giveHoleStringOfCell() {
                cell.recolorCell(cellWasCorrect: true)
            } else {
                solvedCorrect = false
                cell.recolorCell(cellWasCorrect: false)
            }
        }
        testExercise?.solvedCorrect = solvedCorrect
        evaluateButton.isHidden = true
        continueButton.isHidden = false
        parentVC?.resolvedExercise(correct: testExercise!.solvedCorrect)
    }
    
    // Move on to next test
    @IBAction func continuePressed(_ sender: UIButton) {
        tableViewCells = [ClozeTableViewCell]()
        tableView.reloadData()
        evaluateButton.isHidden = false
        continueButton.isHidden = true
        parentVC?.nextTest()
    }
    
    // Creates strings with @___@ for missing words
    func replaceSpecialWords(withUnderlines: Bool) -> [String] {
        var clozeSnippets = testData!.snippets
        var index = 0
        for snippet in clozeSnippets {
            for word in testData!.possibleMissingWords {
                if snippet.contains(word) {
                    var hole = ""
                    if withUnderlines {
                        hole = "@" + String(repeating: "_", count: word.count) + "@"
                    }
                    clozeSnippets[index] = snippet.replacingOccurrences(of: word, with: hole)
                }
            }
            index += 1
        }
        return clozeSnippets
    }
    
    // split strings in array at @ to get rows with array of strings (textfield and label input)
    func createSnippetArray(of array: [String]) -> [[String]] {
        var result = [[String]]()
        var toShowComp = [String]()
        for snippet in array {
            toShowComp = (snippet.components(separatedBy: "@")).filter {$0 != ""}
            result.append(toShowComp)
        }
        return result
    }
    
    // hide keyboard after touch
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.tableView.endEditing(true)
    }
    
    // Remove the view so that the keyboard does not cover the text field
    @objc func keyboardWillShow(sender: NSNotification) {
        self.view.frame.origin.y = -70 // Move view upward
    }
    
    // Remove view to original position
    @objc func keyboardWillHide(sender: NSNotification) {
        self.view.frame.origin.y = 0
    }
    
}
