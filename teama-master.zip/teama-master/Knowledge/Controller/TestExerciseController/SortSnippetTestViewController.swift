//
//  SortSnippetTestViewController.swift
//  Knowledge
//
//  Created by FMA1 on 13.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
SortSnippetTestViewController for test type quiz
*/
class SortSnippetTestViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var testExercise: TestExercise? {
        didSet {
            testData = (testExercise!.testData.returnAsTestDataObject() as! SnippetTestData)
            testDetailDescriptionLabel.text = testData!.taskDescription
            // randomly reorder the elements of an array (never same order)
            snippetsSortedByUser = testData!.snippets.shuffled()
            while snippetsSortedByUser == testData!.snippets {
                snippetsSortedByUser = testData!.snippets.shuffled()
            }
            testDescriptionLabel?.text = testDescription!
            self.tableView.reloadData()
        }
    }
    var testData: SnippetTestData?
    var testDescription: String?
    var snippetsSortedByUser = [String]()
    var parentVC: MasterTestViewController?
    
    @IBOutlet weak var evaluateButton: UIButton!
    @IBOutlet weak var testDescriptionLabel: UILabel!
    @IBOutlet weak var testDetailDescriptionLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var continueButton: UIButton!
    
    
    @IBAction func evaluateButtonPressed(_ sender: UIButton) {
        testExercise?.solved = true
        if snippetsSortedByUser == testData!.snippets {
            testExercise?.solvedCorrect = true
        } else {
            testExercise?.solvedCorrect = false
        }
        evaluateButton.isHidden = true
        continueButton.isHidden = false
        parentVC?.resolvedExercise(correct: testExercise!.solvedCorrect)
        self.tableView.reloadData()
    }
    
    @IBAction func continueButtonPressed(_ sender: UIButton) {
        snippetsSortedByUser = [String]()
        evaluateButton.isHidden = false
        continueButton.isHidden = true
        parentVC?.nextTest()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.setEditing(true, animated: true)
        tableView.allowsSelectionDuringEditing = true
        continueButton.isHidden = true
        evaluateButton.isHidden = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .none
    }
    
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        let movedObject = snippetsSortedByUser[sourceIndexPath.row]
        snippetsSortedByUser.remove(at: sourceIndexPath.row)
        snippetsSortedByUser.insert(movedObject, at: destinationIndexPath.row)
    }
    
    func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return snippetsSortedByUser.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "codeSnippet", for: indexPath)
        cell.textLabel?.text = snippetsSortedByUser[indexPath.row]
        // Recolor background color as feedback
        if testExercise!.solved {
            if snippetsSortedByUser[indexPath.row] == testData!.snippets[indexPath.row] {
                cell.backgroundColor = UIColor(red: 119/255, green: 250/255, blue: 101/255, alpha: 0.4)
            } else {
                cell.backgroundColor = UIColor(red: 228/255, green: 32/255, blue: 32/255, alpha: 0.7)
            }
        } else {
            cell.backgroundColor = UIColor.white
        }
        return cell
    }
    
}
