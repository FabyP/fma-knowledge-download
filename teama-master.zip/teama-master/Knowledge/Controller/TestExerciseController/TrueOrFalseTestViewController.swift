//
//  TrueOrFalseTestViewController.swift
//  Knowledge
//
//  Created by FMA1 on 13.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
TrueOrFalseTestViewController for test type quiz
*/
class TrueOrFalseTestViewController: UIViewController {

    var testExercise: TestExercise? {
        didSet {
            testData = (testExercise!.testData.returnAsTestDataObject() as! StatementTestData)
            startOfAnswerText = testData!.startOfAnswer
            let answers = testData?.answers
            let length = answers?.count
            let number = Int.random(in:  1 ... length!)
            
            for (index, answer) in answers!.enumerated(){
                let index = index + 1
                if index == number {
                    statement = answer
                }
            }
            descriptionLabel.text = testDescription
            statementLabel.text = startOfAnswerText! + " " + statement!.key
        }
    }
    
    var testData: StatementTestData?
    var answered = false
    var parentVC: MasterTestViewController?
    var testDescription: String?
    var startOfAnswerText: String?
    var statement: (key: String, value: Bool)?
    
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var statementLabel: UILabel!
    @IBOutlet weak var continueButton: UIButton!
    
    @IBOutlet weak var trueButton: UIButton!
    @IBOutlet weak var falseButton: UIButton!
    
    @IBAction func onTruePressed(_ sender: Any) {
        testExercise?.solved = true
        if !answered {
            trueButton.layer.borderWidth = 7
            
            if statement!.value == true {
                testExercise?.solvedCorrect = true
                trueButton.layer.borderColor = UIColor.green.cgColor
            } else {
                testExercise?.solvedCorrect = false
                trueButton.layer.borderColor = UIColor.red.cgColor
            }
            afterTest()
        }
    }
    
    @IBAction func onFalsePressed(_ sender: Any) {
        testExercise?.solved = true
        if !answered {
            falseButton.layer.borderWidth = 7
            
            if statement!.value == false {
                testExercise?.solvedCorrect = true
                falseButton.layer.borderColor = UIColor.green.cgColor
            } else {
                testExercise?.solvedCorrect = false
                falseButton.layer.borderColor = UIColor.red.cgColor
            }
            afterTest()
        }
    }
    
    func afterTest() {
        continueButton.isHidden = false
        answered = true
        parentVC?.resolvedExercise(correct: testExercise!.solvedCorrect)
    }

    @IBAction func onContinuePressed(_ sender: Any) {
        answered = false
        continueButton.isHidden = true
        trueButton.layer.borderWidth = 0
        falseButton.layer.borderWidth = 0
        parentVC?.nextTest()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        continueButton?.isHidden = true
    }
}
