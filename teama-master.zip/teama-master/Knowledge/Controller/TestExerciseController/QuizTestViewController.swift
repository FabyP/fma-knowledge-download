//
//  QuizTestViewController.swift
//  Knowledge
//
//  Created by FMA1 on 13.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
 QuizTestViewController for test type quiz
 */
class QuizTestViewController: UIViewController {
    var testExercise: TestExercise? {
        didSet {
            testData = (testExercise!.testData.returnAsTestDataObject() as! StatementTestData)
            questionLabel.text = testData!.question
            exerciseDescriptionLabel.text = testDescription
            let answers = testData?.answers
            
            var button: UIButton = UIButton()
            // Set answers in buttons
            for (index, answer) in answers!.enumerated(){
                let index = index + 1
                button = view.viewWithTag(index) as! UIButton
                button.setTitle(answer.key, for: .normal)
            }
        }
    }
    
    var testData: StatementTestData?
    var answered = false
    var parentVC: MasterTestViewController?
    var testDescription: String?
    var chosenButton: UIButton?
    
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var exerciseDescriptionLabel: UILabel!
    @IBOutlet weak var answersStack: UIStackView!
    @IBOutlet weak var continueButton: UIButton!
    
    // Evaluate answer
    @IBAction func answerAction(_ sender: Any) {
        testExercise?.solved = true
        if !answered {
            let senderTag = (sender as AnyObject).tag
            let answers = testData?.answers.values.map{$0}
            var button: UIButton = UIButton()
            
            button = view.viewWithTag(senderTag!) as! UIButton
            chosenButton = button
            button.layer.borderWidth = 7
            
            if answers![senderTag!-1] == true {
                testExercise?.solvedCorrect = true
                button.layer.borderColor = UIColor.green.cgColor
            } else {
                testExercise?.solvedCorrect = false
                button.layer.borderColor = UIColor.red.cgColor
            }
            
            continueButton.isHidden = false
            answered = true
            parentVC?.resolvedExercise(correct: testExercise!.solvedCorrect)
        }
    }
    
    @IBAction func continuePressed(_ sender: Any) {
        answered = false
        chosenButton!.layer.borderWidth = 0
        continueButton?.isHidden = true
        chosenButton = nil
        parentVC?.nextTest()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        continueButton?.isHidden = true
    }

}
