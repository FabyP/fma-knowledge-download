//
//  ViewController.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit
import CoreData

class TestViewController: UIViewController, UITableViewDataSource , UITableViewDelegate{
    
    @IBOutlet weak var testTableView: UITableView!
    private let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    private var lessons = [Lesson]()
    private var chosenLesson: Lesson?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        testTableView.dataSource = self
        testTableView.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
        let context = container?.viewContext
        let fetchRequest = NSFetchRequest<Lesson>(entityName: "Lesson")
        do {
            lessons = (try context?.fetch(fetchRequest))!
        } catch let err as NSError {
            print("Failed to fetch lessons", err)
        }
        navigationItem.title = "Tests"
        testTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lessons.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let testListCell = UITableViewCell(style: UITableViewCell.CellStyle.value1, reuseIdentifier: "TestListCell")
        
        if lessons[indexPath.row].atLeastOneTestSerieSolvedCorrectly {
            let solvedImageView = UIImageView(image: UIImage(systemName: "checkmark.seal.fill"))
            solvedImageView.tintColor = UIColor.systemGreen
            solvedImageView.translatesAutoresizingMaskIntoConstraints = false
            testListCell.contentView.addSubview(solvedImageView)
            solvedImageView.centerXAnchor.constraint(equalTo: testListCell.contentView.centerXAnchor).isActive = true
            solvedImageView.centerYAnchor.constraint(equalTo: testListCell.contentView.centerYAnchor).isActive = true
            solvedImageView.widthAnchor.constraint(equalToConstant: 25.0).isActive = true
            solvedImageView.heightAnchor.constraint(equalToConstant: 25.0).isActive = true
        }
        
        let lectionList = lessons[indexPath.row].lections
        var everyLectionSeen = true
        
        for lection in lectionList {
            if lection.alreadySeen == false {
                everyLectionSeen = false
            }
        }
        
        // A test can only be started when all the lessons have been seen
        if everyLectionSeen {
            let testExercises = lessons[indexPath.row].currentTestExercises!
            let totalTestsCount = lessons[indexPath.row].intendedNumberOfExercises
            var solvedTestCount = 0
            for testExercise in testExercises {
                if testExercise.solved {
                    solvedTestCount = solvedTestCount + 1
                }
            }
            let testExercisesCount = "\(solvedTestCount) / \(totalTestsCount)"
            testListCell.detailTextLabel?.text = testExercisesCount
            
            if totalTestsCount == solvedTestCount {
                let imageView = UIImageView(image: UIImage(systemName: "repeat"))
                
                let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(repeatTest(tapGestureRecognizer:)))
                testListCell.isUserInteractionEnabled = true
                testListCell.addGestureRecognizer(tapGestureRecognizer)
                
                testListCell.accessoryView = imageView
            }else{
                let imageView = UIImageView(image: UIImage(systemName: "play.circle.fill"))
                testListCell.accessoryView = imageView
                let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(startTest(tapGestureRecognizer:)))
                testListCell.isUserInteractionEnabled = true
                testListCell.addGestureRecognizer(tapGestureRecognizer)
            }
        } else {
            testListCell.accessoryView = UIImageView(image: UIImage(systemName: "lock.fill"))
        }
        
        testListCell.textLabel?.text = lessons[indexPath.row].name!
        
        return testListCell
    }
    
    
    @objc func repeatTest(tapGestureRecognizer: UITapGestureRecognizer) {
        let touch = tapGestureRecognizer.location(in: testTableView)
        if let indexPath = testTableView.indexPathForRow(at: touch) {
            chosenLesson = lessons[indexPath.row]
            do {
                chosenLesson!.currentTestExerciseList = nil
                try chosenLesson!.managedObjectContext?.save()
            } catch let error as NSError {
                print("Error: Couldn't save lesson with tests: ", error)
            }
            createNewTests(for: chosenLesson!)
            performSegue(withIdentifier: "solveTestExercises", sender: self)
        }
    }
    
    @objc func startTest(tapGestureRecognizer: UITapGestureRecognizer) {
        let touch = tapGestureRecognizer.location(in: testTableView)
        if let indexPath = testTableView.indexPathForRow(at: touch) {
            chosenLesson = lessons[indexPath.row]
            // Create new tests if necessary
            if chosenLesson!.currentTestExercises!.isEmpty {
                createNewTests(for: chosenLesson!)
            }
            performSegue(withIdentifier: "solveTestExercises", sender: self)
        }
    }
    
    func createNewTests(for lesson: Lesson) {
        let tests = generateTestExercises(for: lesson)
        for test in tests {
            lesson.addToCurrentTestExerciseList(test)
        }
        do {
            try lesson.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't save lesson with tests: ", error)
        }
    }
    
    // prepare to change scene
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)  {
        if segue.identifier == "solveTestExercises",
            let testExercisesMasterViewController = segue.destination as? MasterTestViewController {
            let backItem = UIBarButtonItem()
            backItem.title = ""
            navigationItem.backBarButtonItem = backItem
            testExercisesMasterViewController.lesson = chosenLesson
        }
    }
}
