//
//  SlideShowItemViewController.swift
//  Knowledge
//
//  Created by FMA1 on 29.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
 Single page of the slideShowViewController
 */
class SlideShowItemViewController: UIViewController {
    
    var item: SlideShowItem?
    var itemIndex = 0
    
    @IBOutlet weak var headlineLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    
    
    override func viewWillAppear(_ animated: Bool) {
        if item != nil {
            headlineLabel.text = item!.headlineLabelText
            descriptionLabel.text = item!.descriptionText
            imageView.image = UIImage(named: item!.imageNames[0])
            if item!.imageNames.count > 1 {
                animateImages()
            }
            if item!.lastItem {
                startButton.isHidden = false
            } else {
                startButton.isHidden = true
            }
        }
    }
    
    // Creates Owlsome after start
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)  {
        if segue.identifier == "startApp"{
            UserDefaults.standard.set(true, forKey: "startDescriptionSeen")
            DefaultDataLoader.preloadOwl()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        imageView.layer.removeAllAnimations()
    }
    
    // Animation for multiple images in item
    private func animateImages() {
        var imageArray = [UIImage]()
        for image in item!.imageNames {
            imageArray.append(UIImage(named: image)!)
        }
        imageView.animationImages = imageArray
        imageView.animationDuration = 0.2 * Double(imageArray.count)
        imageView.animationRepeatCount = 1
        imageView.image = imageView.animationImages![imageView.animationImages!.count - 1]
        imageView.startAnimating()
        
    }
}

struct SlideShowItem {
    var headlineLabelText: String
    var imageNames: [String]
    var descriptionText: String
    var lastItem: Bool // only last item shows the start button
}
