//
//  SlideShowViewController.swift
//  Knowledge
//
//  Created by FMA1 on 29.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
 Slideshow at the first app start
 */
class SlideShowViewController: UIViewController, UIPageViewControllerDataSource {
    
    var pageViewController: UIPageViewController?
    var items = [SlideShowItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setItems()
        createPageViewController()
        setupPageController()
    }
    
    func createPageViewController() {
        let pageController = self.storyboard?.instantiateViewController(withIdentifier: "SlideShowViewController") as! UIPageViewController
        pageController.dataSource = self
        if items.count > 0 {
            let firstController = getItemController(0)!
            let startingViewControllers = [firstController]
            pageController.setViewControllers(startingViewControllers, direction: UIPageViewController.NavigationDirection.forward, animated: false, completion: nil)
        }
        pageViewController = pageController
        addChild(pageViewController!)
        self.view.addSubview(pageViewController!.view)
        pageViewController!.didMove(toParent: self)
    }
    
    func setupPageController() {
        let appearance = UIPageControl.appearance()
        appearance.pageIndicatorTintColor = UIColor.gray
        appearance.currentPageIndicatorTintColor = UIColor.white
        appearance.backgroundColor = UIColor.darkGray
    }
    
    // Return pageViewController with previous item
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let itemController = viewController as! SlideShowItemViewController
        if itemController.itemIndex > 0 {
            return getItemController(itemController.itemIndex - 1)
        }
        return nil
    }
    
    // Return pageViewController with next item
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let itemController = viewController as! SlideShowItemViewController
        if itemController.itemIndex + 1 < items.count {
            return getItemController(itemController.itemIndex + 1)
        }
        return nil
    }
    
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return items.count
    }
    
    func presentationIndex(for pageViewController: UIPageViewController) -> Int {
        return 0
    }
    
    func currentController() -> UIViewController? {
        if (self.pageViewController?.viewControllers?.count)! > 0 {
            return self.pageViewController?.viewControllers![0]
        }
        return nil
    }
    
    func getItemController(_ itemIndex: Int) -> SlideShowItemViewController? {
        if itemIndex < items.count {
            let pageItemController = self.storyboard?.instantiateViewController(withIdentifier: "SlideShowItemViewController") as! SlideShowItemViewController
            pageItemController.itemIndex = itemIndex
            pageItemController.item = items[itemIndex]
            return pageItemController
        }
        return nil
    }
    
    // Texts and images for each page of the slideShowItemViewController
    func setItems() {
        items.append(SlideShowItem(headlineLabelText: "Welcome to ", imageNames: ["knowledge_logo"], descriptionText: "", lastItem: false))
        items.append(SlideShowItem(headlineLabelText: "Owlsome has just emerged from the egg !", imageNames: ["owlsomes_birth_01", "owlsomes_birth_02", "owlsomes_birth_03", "owlsomes_birth_04", "owlsomes_birth_05", "owlsomes_birth_06", "owlsomes_birth_07", "owlsomes_birth_08", "owlsomes_birth_09", "owlsomes_birth_10", "owlsomes_birth_11", "owlsomes_birth_12", "owlsomes_birth_13", "owlsomes_birth_14", "owlsomes_birth_15", "owlsomes_birth_15", "owlsomes_birth_16", "owlsomes_birth_16", "owlsomes_birth_15", "owlsomes_birth_15", "owlsomes_birth_16"], descriptionText: "Now you have to take care of him.", lastItem: false))
        items.append(SlideShowItem(headlineLabelText: "Take care of Owlsome !", imageNames: ["careViewScreen_1"], descriptionText: "In the menu item \"Care\" you can find Owlsome. You can stroke and feed him with knowledge. Owlsome loves books !", lastItem: false))
        items.append(SlideShowItem(headlineLabelText: "Learn swift with Owlsome !", imageNames: ["learnViewScreen"], descriptionText: "In the menu item \"Learn\" you can find lots of lessons about swift with different lections. After you read a lesson completely, you can absolve a test", lastItem: false))
        items.append(SlideShowItem(headlineLabelText: "Test your knowledge !", imageNames: ["testViewScreen"], descriptionText: "In the menu item \"Test\" you can absolve tests of a lesson after you read all lections of them. You can also continue and repeat tests. You earn books for solved tests.", lastItem: false))
        items.append(SlideShowItem(headlineLabelText: "Feed Owlsome !", imageNames: ["careViewScreen_2"], descriptionText: "You can drag the books to Owlsome and feed him. Owlsome gets bored if you don't absolve tests.", lastItem: false))
        items.append(SlideShowItem(headlineLabelText: "Have fun !", imageNames: ["owl_small_normal"], descriptionText: "Now it's time to start the app and to take care of Owlsome", lastItem: true))
    }
}
