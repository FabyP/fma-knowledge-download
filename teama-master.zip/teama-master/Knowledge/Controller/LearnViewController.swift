//
//  FirstViewController.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit
import CoreData

class LearnViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout{

    private let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    private var lessons = [Lesson]()
    private var chosenLesson: Lesson?
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView.contentInset.bottom = (self.tabBarController?.tabBar.frame.height ?? 0) + 50
    }
    
    //get Lessons
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
        let context = container?.viewContext
        let fetchRequest = NSFetchRequest<Lesson>(entityName: "Lesson")
        do {
            lessons = (try context?.fetch(fetchRequest))!
        } catch let err as NSError {
            print("Failed to fetch lessons", err)
        }
        navigationItem.title = "Lessons"
        collectionView.reloadData()
    }
    
    // prepare to change scene
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)  {
      if segue.identifier == "showLections",
         let lectionTableViewController = segue.destination as? LectionTableViewController {
        lectionTableViewController.lesson = chosenLesson
        let backItem = UIBarButtonItem()
        backItem.title = ""
        navigationItem.backBarButtonItem = backItem
      }
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if chosenLesson != nil {
            return true
        }
        return false
    }
    
    //Card Touch Event
    @IBAction func handleCell(sender: UITapGestureRecognizer){
        let tapLocation = sender.location(in: self.collectionView) // Returns the CGPoints of the touched location
        if let indexPath = self.collectionView.indexPathForItem(at: tapLocation) {
            let cell = self.collectionView.cellForItem(at: indexPath) as! CollectionViewCell
            chosenLesson = lessons.filter {
                $0.name! == cell.lessonTitle.text!
            }[0]
            performSegue(withIdentifier: "showLections", sender: self)
        }
    }
    
    //get amount of collectionView cells
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return lessons.count
    }
    
    //fill cells from collectionView
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CollectionViewCell
        
        cell.lessonImage.image = UIImage(named: lessons[indexPath.row].imageName!)
        cell.lessonTitle.text = lessons[indexPath.row].name!
        
        var count = 0
        for lection in lessons[indexPath.row].lections {
            if lection.alreadySeen {
                count += 1
            }
        }
        
        cell.lessonStatus.text = "\(count)/\(lessons[indexPath.row].lections.count) lections"
        cell.layer.cornerRadius = 8.0
        cell.layer.shadowColor = UIColor.black.cgColor
        cell.layer.shadowOffset = CGSize(width: 0, height: 1.0)
        cell.layer.shadowRadius = 8.0
        cell.layer.shadowOpacity = 0.20
        cell.layer.masksToBounds = false
        cell.layer.shadowPath = UIBezierPath(roundedRect: cell.bounds, cornerRadius: cell.contentView.layer.cornerRadius).cgPath

        return cell
    }
    
    //add spacing for collectionView
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets (top: 20, left: 20, bottom: 0, right: 20)
    }
    
    //define card size
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 150, height: 200)
    }
    
}
