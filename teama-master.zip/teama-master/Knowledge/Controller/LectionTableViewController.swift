//
//  LectionTableViewController.swift
//  Knowledge
//
//  Created by FMA1 on 12.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit
import CoreData

/**
 Shows the texts of a lesson
 */
class LectionTableViewController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var indexLabel: UILabel!
    
    private let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    var lesson: Lesson?
    var lectionIndex = 0
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if lesson != nil {
            updateHeaderAndFooterLabels()
            self.tableView.reloadData()
            navigationItem.title = lesson!.name
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        self.tabBarController?.tabBar.isHidden = true
        self.tableView.separatorStyle = .none
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "lectionTextCell", for: indexPath) as? LectionTextCell else {
            fatalError("Unexpected IndexPath")
        }
        let lections = lesson?.lections
        let lectionText = lections?[lectionIndex].texts[indexPath.row]
        if lections != nil {
            setLectionAsAlreadySeen(lesson: lesson!, lectionIndex: lectionIndex)
        }
        // Design of cells
        cell.letctionText.text = lectionText?.text!
        cell.backgroundColor = lectionText!.isCode ? UIColor.black : UIColor.white
        cell.letctionText.font = lectionText!.isCode ? UIFont(name: "Consolas-Bold", size: UIFont.labelFontSize) : UIFont.systemFont(ofSize: 17.0, weight: .regular)
        cell.letctionText.textColor = lectionText!.isCode ? UIColor.white : UIColor.black
        // Set border and text color for code
        if lectionText!.isCode {
            setBorderOfCell(cell: cell)
            cell.letctionText.attributedText = CodeDesigner.getColoredText(text: cell.letctionText.text!)
        }
        
        return cell
       }
       
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return lesson?.lections[lectionIndex].texts.count ?? 0
    }
    
    private func setLectionAsAlreadySeen(lesson: Lesson, lectionIndex: Int){
        do {
            lesson.lections[lectionIndex].alreadySeen = true
            try lesson.managedObjectContext?.save()
        } catch let error as NSError {
            print("Error: Couldn't set lection to already read", error)
        }
    }
    
    private func setBorderOfCell(cell: LectionTextCell) {
        cell.layer.masksToBounds = true
        cell.layer.cornerRadius = 12
        cell.layer.borderWidth = 6
        cell.layer.shadowOffset = CGSize(width: -1, height: 1)
        let borderColor: UIColor = .white
        cell.layer.borderColor = borderColor.cgColor
    }
    
    // Set previous lection
    @IBAction func swipeRight(_ sender: UISwipeGestureRecognizer) {
        if lesson != nil && lectionIndex > 0 {
            lectionIndex -= 1
            tableView.rightToLeftAnimation()
            tableView.reloadData()
            updateHeaderAndFooterLabels()
            setLectionAsAlreadySeen(lesson: lesson!, lectionIndex: lectionIndex)   
        }
    }
    
    // Set next lection
    @IBAction func swipeLeft(_ sender: UISwipeGestureRecognizer) {
        if lesson != nil && (lectionIndex + 1 < lesson!.lections.count) {
            lectionIndex += 1
            tableView.leftToRightAnimation()
            tableView.reloadData()
            updateHeaderAndFooterLabels()
            setLectionAsAlreadySeen(lesson: lesson!, lectionIndex: lectionIndex)
        } else{
            showAlert()
        }
    }
    
    // Alert to start with a test after swipe at last lection
    private func showAlert() {
        let alertController = UIAlertController (title: "Lection finished", message: "Go to test?", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "No", style: .cancel, handler: { (action) in
            _ = self.navigationController?.popToRootViewController(animated: true)
        }))
        alertController.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (action) in
            self.tabBarController?.selectedIndex = 2
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    private func updateHeaderAndFooterLabels() {
        titleLabel.text = lesson?.lections[lectionIndex].title
        indexLabel.text = "\(lectionIndex + 1)/\(lesson?.lections.count ?? 0)"
    }
    
}

// For swipe animation
extension UIView {
    func leftToRightAnimation(duration: TimeInterval = 0.5, completionDelegate: AnyObject? = nil) {
        // Create a CATransation object
        let leftToRightTransition = CATransition()
        if let delegate: AnyObject = completionDelegate {
            leftToRightTransition.delegate = (delegate as! CAAnimationDelegate)
        }
        
        leftToRightTransition.type = CATransitionType.push
        leftToRightTransition.subtype = CATransitionSubtype.fromRight
        leftToRightTransition.duration = duration
        leftToRightTransition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        leftToRightTransition.fillMode = CAMediaTimingFillMode.removed
        
        // Add animation to the View's layer
        self.layer.add(leftToRightTransition, forKey: "leftToRightTransition")
    }
    
    func rightToLeftAnimation(duration: TimeInterval = 0.5, completionDelegate: AnyObject? = nil) {
        // Create a CATransation object
        let leftToRightTransition = CATransition()
        if let delegate: AnyObject = completionDelegate {
            leftToRightTransition.delegate = (delegate as! CAAnimationDelegate)
        }
        
        leftToRightTransition.type = CATransitionType.push
        leftToRightTransition.subtype = CATransitionSubtype.fromLeft
        leftToRightTransition.duration = duration
        leftToRightTransition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        leftToRightTransition.fillMode = CAMediaTimingFillMode.removed
        
        // Add animation to the View's layer
        self.layer.add(leftToRightTransition, forKey: "rightToLeftTransition")
    }
}
