//
//  SecondViewController.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit
import QuartzCore
import CoreData

/**
 CareViewController shows Owlsome, his needs and the inventory
 */
class CareViewController: UIViewController, UIDragInteractionDelegate, UIDropInteractionDelegate {
    
    private let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
    private var owl: Owl?
    private var currentNameOfOwlImage: String?
    
    @IBOutlet weak var owlImageView: UIImageView!
    
    @IBOutlet weak var goldenBookImageView: UIImageView!
    @IBOutlet weak var silverBookImageView: UIImageView!
    @IBOutlet weak var bronzeBookImageView: UIImageView!
    
    @IBOutlet weak var goldenBookLabel: UILabel!
    @IBOutlet weak var silverBookLabel: UILabel!
    @IBOutlet weak var bronzeBookLabel: UILabel!
    
    @IBOutlet weak var hungerNeedIcon: UIImageView!
    @IBOutlet weak var affectionNeedIcon: UIImageView!
    @IBOutlet weak var knowledgeNeedIcon: UIImageView!
    @IBOutlet weak var hungerNeedLabel: UILabel!
    @IBOutlet weak var affectionNeedLabel: UILabel!
    @IBOutlet weak var knowledgeNeedLabel: UILabel!
    
    var affectionToAdd = 0
    var lastIconList = [String]()
    
    var needsTimer: Timer?
    var blinkTimer: Timer?
    

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = false
        view.addInteraction(UIDragInteraction(delegate: self))
        navigationItem.title = "Owlsome"
        let context = container?.viewContext
        let fetchRequest = NSFetchRequest<Owl>(entityName: "Owl")
        do {
            let response = try context?.fetch(fetchRequest)
            owl = response?[0]
            checkLevelUp()
            // Update owlsome data
            owl?.pointsLeftForNextLevel = LevelDesigner.neededPoints(for: owl!.currentLevel + 1) - owl!.reachedPoints
            reduceNeedsAfterBreak(by: owl!.lastInteractionTimestamp)
            updateNeeds()
            updateEmotionAndImage()
            owl?.lastInteractionTimestamp = Date()
            setBookCountLabel()
            setBookInteraction()
            saveOwl()
        } catch let error as NSError {
            print("Failed to fetch owl: ", error)
        }
        startNeedsTimer()
        startBlinkTimer()
    }
    
    // To animate level up (if necessary)
    private func checkLevelUp() {
        let oldLevel = owl!.currentLevel
        let newLevel = LevelDesigner.getCurrentLevel(reachedPoints: self.owl!.reachedPoints)
        owl?.currentEmotion = LevelDesigner.calculateEmotion(affection: owl!.affection, hunger: owl!.hunger, lastSolvedTimestamp: owl!.lastSolvedTestTimestamp)
        if oldLevel < newLevel {
            let oldImage = UIImage(named: LevelDesigner.getImageNameForEmotionAndLevel(emotion: owl!.currentEmotion, level: oldLevel))
            self.owlImageView!.image = oldImage
            let newImage = UIImage(named: LevelDesigner.getImageNameForEmotionAndLevel(emotion: owl!.currentEmotion, level: newLevel))
            self.owlImageView!.layoutIfNeeded()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                self.owlImageView!.transform = CGAffineTransform(scaleX: 0, y: 0)
                UIView.animate(withDuration: 3, delay: 0, usingSpringWithDamping: 0.3, initialSpringVelocity: 0, options: .curveEaseOut, animations: {
                    self.owlImageView!.image = newImage
                    self.owlImageView!.transform = .identity
                }, completion: nil)
            self.owl?.currentLevel = LevelDesigner.getCurrentLevel(reachedPoints: self.owl!.reachedPoints)
            self.updateEmotionAndImage()
            }
        } else {
            self.owl?.currentLevel = LevelDesigner.getCurrentLevel(reachedPoints: self.owl!.reachedPoints)
            self.updateEmotionAndImage()
        }
    }
    
    // Update label text and animation of need icon
    private func updateNeeds() {
        updateNeedLabels()
        animateNeedIconsIfNecessary()
    }
    
    // Update values of needs
    private func reduceNeedsAfterBreak(by lastInteractionTimestamp: Date) {
        let diffComponents = Calendar.current.dateComponents([.second], from: owl!.lastInteractionTimestamp, to: Date())
        let factor = Int(Double(diffComponents.second!)/LevelDesigner.timeIntervalForNeedsInSeconds)
        owl?.affection = max(0, owl!.affection - LevelDesigner.amountOfReducedAffectionInTimeInterval * factor)
        owl?.hunger = max(0, owl!.hunger - LevelDesigner.amountOfReducedHungerInTimeInterval * factor)
    }
    
    private func updateEmotionAndImage() {
        owl?.currentEmotion = LevelDesigner.calculateEmotion(affection: owl!.affection, hunger: owl!.hunger, lastSolvedTimestamp: owl!.lastSolvedTestTimestamp)
        currentNameOfOwlImage = LevelDesigner.getImageNameForEmotionAndLevel(emotion: owl!.currentEmotion, level: Int(owl!.currentLevel))
        self.owlImageView?.image = UIImage(named: self.currentNameOfOwlImage!)
        saveOwl()
    }
    
    private func updateNeedLabels() {
        affectionNeedLabel?.text = "\(owl!.affection) %"
        knowledgeNeedLabel?.text  = "\(LevelDesigner.calculatePercentageOfKnowledgeNeed(lastSolvedTimestamp: owl!.lastSolvedTestTimestamp)) %"
        hungerNeedLabel?.text = "\(owl!.hunger) %"
    }
    
    private func resetIcon(of imageView: UIImageView) {
        imageView.layer.removeAllAnimations()
        imageView.transform = .identity
    }
     
    private func animateNeedIconsIfNecessary() {
        let iconList = LevelDesigner.getIconNamesToAnimate(affection: owl!.affection, hunger: owl!.hunger, lastSolvedTimestamp: owl!.lastSolvedTestTimestamp)
        if lastIconList != iconList {
            lastIconList = iconList
            resetNeedLabelsAndIcons()
            animateIconImages()
        }
    }
    
    private func resetNeedLabelsAndIcons() {
        resetIcon(of: affectionNeedIcon)
        affectionNeedLabel.textColor = .black
        resetIcon(of: hungerNeedIcon)
        hungerNeedLabel.textColor = .black
        resetIcon(of: knowledgeNeedIcon)
        knowledgeNeedLabel.textColor = .black
    }

    private func animateIconImages() {
        if lastIconList.contains(LevelDesigner.iconNameForNeeds[.angry]!) {
            startIconAnimation(imageView: hungerNeedIcon)
            hungerNeedLabel.textColor = .red
        }
        if lastIconList.contains(LevelDesigner.iconNameForNeeds[.sad]!) {
            startIconAnimation(imageView: affectionNeedIcon)
            affectionNeedLabel.textColor = .red
        }
        if lastIconList.contains(LevelDesigner.iconNameForNeeds[.bored]!) {
            startIconAnimation(imageView: knowledgeNeedIcon)
            knowledgeNeedLabel.textColor = .red
        }
    }

    private func startIconAnimation(imageView: UIImageView) {
        UIImageView.animateKeyframes(withDuration: 1.5, delay: 0.0, options: [.autoreverse, .repeat], animations: {
            UIImageView.addKeyframe(withRelativeStartTime: 0.0, relativeDuration: 2, animations: {
                imageView.transform = CGAffineTransform(scaleX: 1.5, y: 1.5)
            })
        },
        completion: nil)
    }
    
    // Owlsome blinks every 5 seconds
    private func startBlinkTimer() {
        blinkTimer = Timer.scheduledTimer(timeInterval: 5, target: self, selector: #selector(owlBlink), userInfo: nil, repeats: true)
    }
    
    private func startNeedsTimer() {
        needsTimer = Timer.scheduledTimer(timeInterval: LevelDesigner.timeIntervalForNeedsInSeconds, target: self, selector: #selector(reduceNeeds), userInfo: nil, repeats: true)
    }
    
    @objc private func reduceNeeds() {
        owl!.affection = max(0, owl!.affection - LevelDesigner.amountOfReducedAffectionInTimeInterval)
        owl!.hunger = max(0, owl!.hunger - LevelDesigner.amountOfReducedHungerInTimeInterval)
        owl!.lastInteractionTimestamp = Date()
        if !self.currentNameOfOwlImage!.contains(LevelDesigner.getAdditionForAction()) && !self.currentNameOfOwlImage!.contains(LevelDesigner.getAdditionForFeeding()) {
            updateEmotionAndImage()
        }
        updateNeeds()
        saveOwl()
    }
    
    @objc private func owlBlink() {
        let imageForEyesClosed = LevelDesigner.getImageNameWhileBlinkForLevel(level: Int((owl?.currentLevel)!))
        if !self.currentNameOfOwlImage!.contains(LevelDesigner.getAdditionForAction()) && !self.currentNameOfOwlImage!.contains(LevelDesigner.getAdditionForFeeding()) {
            owlImageView?.image = UIImage(named: imageForEyesClosed)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                if !self.currentNameOfOwlImage!.contains(LevelDesigner.getAdditionForAction()) {
                    self.updateEmotionAndImage()
                }
            }
        }
    }
    
    // Stop timer and reset needs
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        saveOwl()
        lastIconList = []
        resetNeedLabelsAndIcons()
        needsTimer?.invalidate()
        blinkTimer?.invalidate()
    }
    
    private func setBookCountLabel() {
        let countOfGoldBooks = owl!.inventory.filter({book in return book.points == Book.books.gold.points}).count
        let countOfSilverBooks = owl!.inventory.filter({book in return book.points == Book.books.silver.points}).count
        let countOfBronzeBooks = owl!.inventory.filter({book in return book.points == Book.books.bronze.points}).count
        goldenBookLabel.text = "\(String(describing: countOfGoldBooks))x"
        silverBookLabel.text = "\(String(describing: countOfSilverBooks))x"
        bronzeBookLabel.text = "\(String(describing: countOfBronzeBooks))x"
    }
    
    // Add Drag&Drop for books in inventory
    private func setBookInteraction() {
        let countOfGoldBooks = owl!.inventory.filter({book in return book.points == Book.books.gold.points}).count
        let countOfSilverBooks = owl!.inventory.filter({book in return book.points == Book.books.silver.points}).count
        let countOfBronzeBooks = owl!.inventory.filter({book in return book.points == Book.books.bronze.points}).count
        
        if countOfGoldBooks > 0 {
            let dragInteraction = UIDragInteraction(delegate: self)
            dragInteraction.isEnabled = true
            goldenBookImageView.isUserInteractionEnabled = true
            goldenBookImageView.addInteraction(dragInteraction)
        } else {
            goldenBookImageView.isUserInteractionEnabled = false
        }
        
        if countOfSilverBooks > 0 {
            let dragInteraction = UIDragInteraction(delegate: self)
            dragInteraction.isEnabled = true
            silverBookImageView.isUserInteractionEnabled = true
            silverBookImageView.addInteraction(dragInteraction)
        } else {
            silverBookImageView.isUserInteractionEnabled = false
        }
        
        if countOfBronzeBooks > 0 {
            let dragInteraction = UIDragInteraction(delegate: self)
            dragInteraction.isEnabled = true
            bronzeBookImageView.isUserInteractionEnabled = true
            bronzeBookImageView.addInteraction(dragInteraction)
        } else {
            bronzeBookImageView.isUserInteractionEnabled = false
        }
        
        if(countOfGoldBooks > 0 ||  countOfSilverBooks > 0 || countOfBronzeBooks > 0){
            let dropInteraction = UIDropInteraction(delegate: self)
            view.addInteraction(dropInteraction)
        }
    }
    
    
    func dragInteraction(_ interaction: UIDragInteraction, itemsForBeginning session: UIDragSession) -> [UIDragItem] {
        let touchedPoint = session.location(in: self.view)
        if let touchedImageView = self.view.hitTest(touchedPoint, with: nil) as? UIImageView{
            let touchedImage = touchedImageView.image
            let itemProvider = NSItemProvider(object: touchedImage!)
            let dragItem = UIDragItem(itemProvider: itemProvider)
            return [dragItem]
        }
        
        return []
    }
    
    func dropInteraction(_ interaction: UIDropInteraction, canHandle session: UIDropSession) -> Bool {
        return session.canLoadObjects(ofClass: UIImage.self) && session.items.count == 1
    }

    func dropInteraction(_ interaction: UIDropInteraction, sessionDidUpdate session: UIDropSession) -> UIDropProposal {
        let dropLocation = session.location(in: view)
        let operation: UIDropOperation
        if owlImageView.frame.contains(dropLocation) {
            currentNameOfOwlImage = LevelDesigner.getImageNameWhileFeedingForEmotionAndLevel(emotion: owl!.currentEmotion, level: owl!.currentLevel)
            owlImageView?.image = UIImage(named: currentNameOfOwlImage!)
            operation = session.localDragSession == nil ? .copy : .move
        } else {
            self.updateEmotionAndImage()
            operation = .cancel
        }

        return UIDropProposal(operation: operation)
    }

    // Add points of books to need hunger after feeding
    func dropInteraction(_ interaction: UIDropInteraction, performDrop session: UIDropSession) {
        session.loadObjects(ofClass: UIImage.self) { imageItems in
            guard let images = imageItems as? [UIImage] else { return }
            
            let bronzeBookImage = self.bronzeBookImageView.image
            let silverBookImage = self.silverBookImageView.image
            let goldenBookImage = self.goldenBookImageView.image
            
            var owlInventory = self.owl?.inventory
            var bookPoints = 0
            
            if self.compareImage(images.first, isEqualTo: bronzeBookImage) {
                bookPoints = Book.books.bronze.points
                self.owl?.hunger = min(self.owl!.hunger + bookPoints, 100)
            }
            
            if self.compareImage(images.first, isEqualTo: silverBookImage) {
                bookPoints = Book.books.silver.points
                self.owl?.hunger = min(self.owl!.hunger + bookPoints, 100)
            }
            
            if self.compareImage(images.first, isEqualTo: goldenBookImage) {
                bookPoints = Book.books.gold.points
                self.owl?.hunger = min(self.owl!.hunger + bookPoints, 100)
            }
            
            for (i,book) in owlInventory!.enumerated(){
                if(book.points == bookPoints){
                    owlInventory!.remove(at: i)
                    self.owl?.removeFromBookList(book)
                    break
                }
            }
            self.updateEmotionAndImage()
            self.updateNeeds()
            self.saveOwl()
            self.setBookCountLabel()
            self.setBookInteraction()
        }
    }
    
    func compareImage(_ image1: UIImage?, isEqualTo image2: UIImage?) -> Bool {
        let data1 = image1?.pngData()
        let data2 = image2?.pngData()
        
        return data1 == data2
    }
    
    // Animation for Owlsome while interaction
    private func owlsomeAnimation() {
        // Run animation sequence
        let scaleDeltaHeight = CGFloat(0.08)
        let scaleDeltaWidth = CGFloat(0.05)
        let wiggleOutHorizontally = CGAffineTransform(scaleX: 1.0 + scaleDeltaWidth, y: 1.0)
        let wiggleOutVertically = CGAffineTransform(scaleX: 1.0, y: 1.0 + scaleDeltaHeight)
        UIImageView.animateKeyframes(withDuration: 0.5, delay: 0.0, options: [.autoreverse, .repeat], animations: {
             // Animate wiggle horizontally
            UIImageView.addKeyframe(withRelativeStartTime: 0.0, relativeDuration: 2, animations: {
                self.owlImageView?.transform = wiggleOutHorizontally
            })
            // Animate wiggle vertically
            UIImageView.addKeyframe(withRelativeStartTime: 0.0, relativeDuration: 2, animations: {
                self.owlImageView?.transform = wiggleOutVertically
            })
        },
        completion: nil)
    }

    private func shortAnmiation() {
        currentNameOfOwlImage = LevelDesigner.getImageNameForEmotionAndLevel(emotion: .happy, level: Int((owl?.currentLevel)!))
        self.owlImageView?.image = UIImage(named: currentNameOfOwlImage!)
        self.owlsomeAnimation()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            self.owlImageView?.layer.removeAllAnimations()
            self.addAffectionToOwlsome(value: self.affectionToAdd)
        }
    }

    @IBAction func swipeRight(_ sender: UISwipeGestureRecognizer) {
        affectionToAdd = 20
        shortAnmiation()
    }
    
    
    @IBAction func swipeLeft(_ sender: UISwipeGestureRecognizer) {
        affectionToAdd = 20
        shortAnmiation()
    }
    
    @IBAction func swipeDown(_ sender: UISwipeGestureRecognizer) {
        affectionToAdd = 5
        shortAnmiation()
    }
    
    
    @IBAction func swipeUp(_ sender: UISwipeGestureRecognizer) {
        affectionToAdd = 5
        shortAnmiation()
    }
    
    // Continues animation for Owlsome as long as interaction lasts
    @IBAction func longPress(_ sender: UILongPressGestureRecognizer) {
        currentNameOfOwlImage = LevelDesigner.getImageNameForEmotionAndLevel(emotion: .happy, level: Int((owl?.currentLevel)!))
        if sender.state == .began {
            owlImageView?.image = UIImage(named: currentNameOfOwlImage!)
            owlsomeAnimation()
        }
        else if sender.state == .ended {
            owlImageView?.layer.removeAllAnimations()
            addAffectionToOwlsome(value: 30)
        }
    }
    
    @IBAction func tapped(_ sender: UITapGestureRecognizer) {
        affectionToAdd = 15
        shortAnmiation()
    }
    
    private func addAffectionToOwlsome(value: Int) {
        owl?.affection = min(100, owl!.affection + value)
        owl?.lastInteractionTimestamp = Date()
        updateEmotionAndImage()
        updateNeeds()
        saveOwl()
    }
    
    private func saveOwl() {
        do {
            try owl!.managedObjectContext?.save()
        } catch let error as NSError {
            print("Couldn't save Owlsome", error)
        }
    }
    
}

