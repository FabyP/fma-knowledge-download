//
//  CodeDesigner.swift
//  Knowledge
//
//  Created by FMA1 on 03.07.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit


/**
 Helper class to set color attributes for different keywords in a code block
 */
public class CodeDesigner {
    
    private static let keyWords = ["break", "case", "catch", "class", "default", "do", "else", "for", "func", "if", "import", "in", "let", "nil", "return", "switch", "throws", "try", "var"]
    private static let types = ["Character", "Int", "Set", "String"]
    
    private static let keyWordColor = hexStringToUIColor(hex: "#569cd6")
    private static let typeColor = hexStringToUIColor(hex: "#3dc9b0")
    private static let numberColor = hexStringToUIColor(hex: "#b5cea8")
    private static let stringColor = hexStringToUIColor(hex: "#ce9178")
    private static let commentColor = hexStringToUIColor(hex: "#608b4e")
    
    // Returns a NSMutableAttributedString with color attributes for every (different colored) code
    static func getColoredText(text: String) -> NSMutableAttributedString {
        let string = NSMutableAttributedString(string: text)
        recolorNumbers(text: text, attributedString: string) // Recolor numbers
        recolorKeywords(text: text, attributedString: string) // Recolor keywords
        recolorTypes(text: text, attributedString: string) // Recolor types
        recolorStrings(text: text, attributedString: string) // Recolor strings
        recolorVariablesInStrings(text: text, attributedString: string)// Recolor values between string
        recolorFunctionCalls(text: text, attributedString: string) // Recolor comments
        recolorComments(text: text, attributedString: string) // Recolor comments
        return string
    }
    
    // Recolor float, int and double values
    private static func recolorNumbers(text: String, attributedString: NSMutableAttributedString) {
        var foundNumbers = [String]()
        let substrings = text.components(separatedBy: CharacterSet(charactersIn: " \n[]():"))
        for word in substrings {
            // check if it is a number (a word with letters would be a variable)
            if word.containsNumbers() && !word.containsLetters() {
                foundNumbers.append(word)
            }
        }
        for key in foundNumbers {
            let ranges = text.getRanges(of: key, seperators: " \n[]():")
            for range in ranges {
                attributedString.addAttributes([NSAttributedString.Key.foregroundColor: numberColor], range: range)
            }
        }
    }
    
    // Recolor special keywords
    private static func recolorKeywords(text: String, attributedString: NSMutableAttributedString) {
        for key in keyWords {
            let ranges = text.getRanges(of: key, seperators: " \n[]():.")
            for range in ranges {
                attributedString.addAttributes([NSAttributedString.Key.foregroundColor: keyWordColor], range: range)
            }
        }
    }
   
    // Recolor data type names
    private static func recolorTypes(text: String, attributedString: NSMutableAttributedString) {
        for key in types {
            let ranges = text.getRanges(of: key, seperators: " \n[]():.<>,")
            for range in ranges {
                attributedString.addAttributes([NSAttributedString.Key.foregroundColor: typeColor], range: range)
            }
        }
    }
    
    // Recolor string values
    private static func recolorStrings(text: String, attributedString: NSMutableAttributedString) {
        text.ranges(of: "\"[^\"]*\"", options: .regularExpression)
            .map { NSRange($0, in: text) }
            .forEach {
                attributedString.setAttributes([NSAttributedString.Key.foregroundColor: stringColor], range: $0)
        }
    }

   // Reset recoloring for parts with \(...) in strings
    private static func recolorVariablesInStrings(text: String, attributedString: NSMutableAttributedString) {
        let foundStrings = matches(for: "[\\\\]+[/\\(][^/\\)]*[/\\)]", in: text)
        for key in foundStrings {
            let range = (text as NSString).range(of: key)
            attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: UIColor.white , range: range)
        }
    }
    
    // Recolor comments in code with //
    private static func recolorComments(text: String, attributedString: NSMutableAttributedString) {
        let foundComments = matches(for: "[//]{2}[^/\n)]*", in: text)
        for comment in foundComments {
            let range = (text as NSString).range(of: comment)
            attributedString.addAttribute(NSAttributedString.Key.foregroundColor, value: commentColor , range: range)
        }
    }
    
    // Recolor function calls
    private static func recolorFunctionCalls(text: String, attributedString: NSMutableAttributedString) {
        // text.ranges(of: "[.][^/\\()]*[(]", options: .regularExpression)
        // text.ranges(of: "[.][^/\\]*(/\\(|/\\)|/\\[|/\\]| )", options: .regularExpression)
        text.ranges(of: "[.][^/\\() ]*[(| |)]", options: .regularExpression)
            .map { NSRange($0, in: text) }
            .forEach {
                var range = $0
                range.length += -2
                range.location += 1
                attributedString.setAttributes([NSAttributedString.Key.foregroundColor: typeColor], range: range)
        }
    }
    
    // Returns text ranges which matches the regex
    private static func matches(for regex: String, in text: String) -> [String] {
        do {
            let regex = try NSRegularExpression(pattern: regex)
            let results = regex.matches(in: text, range: NSRange(text.startIndex..., in: text))
            return results.map {
                String(text[Range($0.range, in: text)!])
            }
        } catch let error {
            print("invalid regex: \(error.localizedDescription)")
            return []
        }
    }
    
    // Convert a hex color code to UIColor
    private static func hexStringToUIColor(hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
}

// Returns an array of ranges which matches the string (regular expression) > to get multiple matches and without need
extension StringProtocol where Index == String.Index {
    func ranges<T: StringProtocol>(of string: T, options: String.CompareOptions = []) -> [Range<Index>] {
        var ranges: [Range<Index>] = []
        var start: Index = startIndex

        while let range = range(of: string, options: options, range: start..<endIndex) {
            ranges.append(range)
            start = range.upperBound
        }
        return ranges
    }
}

extension String {
    // Returns the range of asked string (a separated word must contain hole string)
    func getRanges(of string: String, seperators: String) -> [NSRange] {
        var ranges:[NSRange] = []
        if contains(string) {
            let words = self.components(separatedBy: CharacterSet(charactersIn: seperators))
            var position:Int = 0
            for word in words {
                if word.lowercased() == string.lowercased() {
                    let startIndex = position
                    let endIndex = word.count
                    let range = NSMakeRange(startIndex, endIndex)
                    ranges.append(range)
                }
                position += (word.count + 1)
            }
        }
        return ranges
    }
    
    // Returns if the string contains at least one number
    func containsNumbers() -> Bool {
        let numberRegEx  = ".*[0-9]+.*"
        let testCase     = NSPredicate(format:"SELF MATCHES %@", numberRegEx)
        return testCase.evaluate(with: self)
    }
    
    // Returns if the string contains at least one character
    func containsLetters() -> Bool {
        let letterRegEx  = ".*[a-z]+.*"
        let testCase     = NSPredicate(format:"SELF MATCHES %@", letterRegEx)
        return testCase.evaluate(with: self)
    }
}

// Extension to work easily with regular expressions
extension NSRegularExpression {
    convenience init(_ pattern: String) {
        do {
            try self.init(pattern: pattern)
        } catch {
            preconditionFailure("Illegal regular expression: \(pattern).")
        }
    }
    
    func matches(_ string: String) -> Bool {
           let range = NSRange(location: 0, length: string.utf16.count)
           return firstMatch(in: string, options: [], range: range) != nil
       }
}
