//
//  CollectionViewCell.swift
//  Knowledge
//
//  Created by FMA1 on 12.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
CollectionViewCell for LearnViewController
*/
class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var lessonImage: UIImageView!
    @IBOutlet weak var lessonTitle: UILabel!
    @IBOutlet weak var lessonStatus: UILabel!
}
