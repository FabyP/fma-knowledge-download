//
//  ClozeTableViewCell.swift
//  Knowledge
//
//  Created by FMA1 on 15.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
 ClozeTableViewCell for ClozeTestViewController
 */
class ClozeTableViewCell: UITableViewCell, UITextFieldDelegate {

    // stack with labels and textfield of a code row
    let stackView = UIStackView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    // Set layout for cell
    func commonInit() {
        self.selectionStyle = UITableViewCell.SelectionStyle.none
        stackView.axis = .horizontal
        stackView.distribution = .fillProportionally
        stackView.alignment = .center
        stackView.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stackView)
        stackView.bottomAnchor.constraint(equalTo: bottomAnchor).isActive = true
    }
    
    // Create textfields and labels
    func setup(values: [String]) {
        for value in values {
            
            // Create textfield
            if hasSpecialCharacters(word: value) {
                let textfield = UITextField()
                textfield.placeholder = value
                textfield.placeholder = value
                textfield.borderStyle = UITextField.BorderStyle.roundedRect
                textfield.autocorrectionType = UITextAutocorrectionType.no
                textfield.autocapitalizationType = .none
                textfield.keyboardType = UIKeyboardType.default
                textfield.returnKeyType = UIReturnKeyType.done
                textfield.clearButtonMode = UITextField.ViewMode.never
                textfield.delegate = self
                let newSize = CGSize(width: value.count, height: 10)
                let newFrame = CGRect(origin: textfield.frame.origin, size: newSize)
                textfield.frame = newFrame
                textfield.setNeedsDisplay()
                textfield.font = textfield.font?.withSize(13)
                stackView.addArrangedSubview(textfield)
                
            // Create label
            } else {
                let label = UILabel()
                label.text = value
                label.font = label.font.withSize(13)
                label.setNeedsLayout()
                stackView.addArrangedSubview(label)
            }
        }
    }
    
    // Concat string of cell stack for evaluation
    func giveHoleStringOfCell() -> String {
        var string = ""
        for element in stackView.arrangedSubviews {
            if let t = element as? UITextField {
                string += t.text!
            } else if let t = element as? UILabel{
                string += t.text!
            }
        }
        return string
    }
    
    // Checks if the string contains only placeholder text (for label/textfield check)
    func hasSpecialCharacters(word: String) -> Bool {
        do {
            let regex = try NSRegularExpression(pattern: ".*[_].*", options: .caseInsensitive)
            if let _ = regex.firstMatch(in: word, options: NSRegularExpression.MatchingOptions.reportCompletion, range: NSMakeRange(0, word.count)) {
                return true
            }
        } catch {
            debugPrint(error.localizedDescription)
            return false
        }
        return false
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }

    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        return true
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return true
    }

    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return false
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Recolor cell background for evaluation feedback
    func recolorCell(cellWasCorrect: Bool) {
        if cellWasCorrect {
            self.backgroundColor = UIColor(red: 119/255, green: 250/255, blue: 101/255, alpha: 0.4)
        } else {
            self.backgroundColor = UIColor(red: 228/255, green: 32/255, blue: 32/255, alpha: 0.7)
        }
    }
    
    // Size of textField by missed letters
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        let maxLength = textField.placeholder!.count
        let currentString: NSString = textField.text! as NSString
        let newString: NSString =
            currentString.replacingCharacters(in: range, with: string) as NSString
        return newString.length <= maxLength
    }

}
