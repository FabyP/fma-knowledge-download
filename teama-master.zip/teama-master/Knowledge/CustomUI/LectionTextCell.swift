//
//  LectionTextCell.swift
//  Knowledge
//
//  Created by FMA1 on 12.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import UIKit

/**
 LectionTextCell for LectionTableViewController
 */
class LectionTextCell: UITableViewCell {

    @IBOutlet weak var letctionText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code for resizing label size
        letctionText.numberOfLines = 0
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

}
