//
//  LectionText+CoreDataClass.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

@objc(LectionText)
public class LectionText: NSManagedObject {

    convenience init?(isCode: Bool, text: String, index: Int){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: LectionText.entity(), insertInto: context)
        self.isCode = isCode
        self.text = text
        self.index = Int16(index)
    }
}
