//
//  TestExercise+CoreDataClass.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

@objc(TestExercise)
public class TestExercise: NSManagedObject {

    var testData: TestData {
        return self.usedTestData as TestData
    }
    
    var index: Int {
        return Int(indexInt16)
    }
    
    var testTypeEnum: TestType {
        return TestType(rawValue: testType)!
    }
    
    convenience init?(testType: TestType, usedTestData: TestData, index: Int){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: TestExercise.entity(), insertInto: context)
        self.testType = testType.description
        self.usedTestData = usedTestData
        self.solved = false
        self.solvedCorrect = false
        self.indexInt16 = Int16(index)
    }
}
