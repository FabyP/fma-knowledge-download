//
//  TestData.swift
//  ProjectTest
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import Foundation

protocol TestDataProtocol {
    var validTestTypes: [TestType] { get set }
}

let testTypeForSnippetTestData: [TestType] = [.sortSnippets, .cloze]
let testTypeForStatementTestData: [TestType] = [.quiz, .trueOrFalse]

class SnippetTestData: TestDataProtocol {
    var validTestTypes: [TestType]
    var taskDescription: String
    var snippets:[String]
    var possibleMissingWords: [String]
    
    init(taskDescription: String, snippets: [String], possibleMissingWords: [String]) {
        self.validTestTypes = testTypeForSnippetTestData
        self.taskDescription = taskDescription
        self.snippets = snippets
        self.possibleMissingWords = possibleMissingWords
    }
}

class StatementTestData: TestDataProtocol {
    var validTestTypes: [TestType]
    var question: String
    var startOfAnswer: String
    var answers: [String: Bool]
    
    init(question: String, startOfAnswer: String, answers: [String: Bool]) {
        self.validTestTypes = testTypeForStatementTestData
        self.question = question
        self.startOfAnswer = startOfAnswer
        self.answers = answers
    }
}

func generateTestExercises(for lesson: Lesson) -> [TestExercise] {
    var testExercises = [TestExercise]()
    let intendedNumberOfTests = lesson.intendedNumberOfExercises
    let testData = lesson.testData
    let chosenTestData = testData.pick(intendedNumberOfTests)
    // var alreadyChosenTypes = [TestType]()
    var alreadyChosenTypes = [TestType: Int]()
    for value in TestType.allCases {
        alreadyChosenTypes[value] = 0
    }
    
    var index = 0
    for testData in chosenTestData {
        var possibleTypes = [TestType: Int]()
        for type in testData.validTestTypes {
            possibleTypes[type] = alreadyChosenTypes[type]
        }
        let highestAndLowestValue = ((possibleTypes.min { a, b in a.value < b.value })!.key, (possibleTypes.max { a, b in a.value < b.value })!.key)
        var chosenTestDataType: TestType
        if highestAndLowestValue.0 == highestAndLowestValue.1 {
            chosenTestDataType = (testData.validTestTypes.pick(1))[0]
        } else {
            chosenTestDataType = (possibleTypes.min { a, b in a.value < b.value })!.key
        }

        alreadyChosenTypes[chosenTestDataType] = alreadyChosenTypes[chosenTestDataType]! + 1
        let testExercise = TestExercise(testType: chosenTestDataType, usedTestData: testData, index: index)!
        testExercises.append(testExercise)
        
        index += 1
    }
    print("-----")
    print("Generated TestExercises for Lesson \(lesson.name!)")
    for test in testExercises {
        print(test.testType)
    }
    return testExercises
}

// Pick random element of array
extension Array {
    func pick(_ n: Int) -> [Element] {
        guard count >= n else {
            fatalError("The count has to be at least \(n)")
        }
        guard n >= 0 else {
            fatalError("The number of elements to be picked must be positive")
        }

        let shuffledIndices = indices.shuffled().prefix(upTo: n)
        return shuffledIndices.map {self[$0]}
    }
}
