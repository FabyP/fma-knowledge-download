//
//  LectionText+CoreDataProperties.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData


extension LectionText {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<LectionText> {
        return NSFetchRequest<LectionText>(entityName: "LectionText")
    }

    @NSManaged public var isCode: Bool
    @NSManaged public var text: String?
    @NSManaged public var lection: Lection?
    @NSManaged public var index: Int16

}
