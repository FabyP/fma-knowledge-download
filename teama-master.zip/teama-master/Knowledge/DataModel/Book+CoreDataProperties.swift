//
//  Book+CoreDataProperties.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData


/**
Generated extension for book, which contains data types of the model in Knowledge.xcdatamodeld
*/
extension Book {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Book> {
        return NSFetchRequest<Book>(entityName: "Book")
    }

    @NSManaged public var pointsInt16: Int16
    @NSManaged public var imageName: String
    @NSManaged public var owl: Owl?
    
}
