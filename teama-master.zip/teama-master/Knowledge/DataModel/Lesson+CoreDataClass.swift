//
//  Lesson+CoreDataClass.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

@objc(Lesson)
public class Lesson: NSManagedObject {
    
    // Returns list of lections sorted by index (as expected)
    var lections: [Lection] {
        return (self.lectionList?.allObjects as! [Lection]).sorted { (l1, l2) -> Bool in
            Int(l1.index) < Int(l2.index)
        }
    }
    
    // Returns list with testData objects
    var testData: [TestData] {
        return self.testDataList?.allObjects as! [TestData]
    }
    
    // Returns list with test exercises sorted by index (if transformable currentTestExerciseList is set)
    var currentTestExercises: [TestExercise]? {
        return (self.currentTestExerciseList?.allObjects as! [TestExercise]).sorted { (t1, t2) -> Bool in
            Int(t1.index) < Int(t2.index)
        }
    }
    
    // Returns number of exercises as Int
    var intendedNumberOfExercises: Int {
        return Int(self.intendedNumberOfExercisesInt16)
    }
    
    convenience init?(name: String, imageName: String, intendedNumberOfExercises: Int){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: Lesson.entity(), insertInto: context)
        self.name = name
        self.imageName = imageName
        self.intendedNumberOfExercisesInt16 = Int16(intendedNumberOfExercises)
        self.atLeastOneTestSerieSolvedCorrectly = false
    }
}
