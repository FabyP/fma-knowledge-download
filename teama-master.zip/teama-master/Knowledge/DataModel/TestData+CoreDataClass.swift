//
//  TestData+CoreDataClass.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

@objc(TestData)
public class TestData: NSManagedObject {
    
    var validTestTypes: [TestType] {
        let validTestTypesAsStrings = self.validTestTypeList as! [String]
        var listOfTestTypes = [TestType]()
        for type in validTestTypesAsStrings {
            listOfTestTypes.append(TestType(rawValue: type)!)
        }
        return listOfTestTypes
    }
    
    // For SnippetTestData
    var snippets: [String]? {
        return self.snippetList as? [String]
    }
    
    // For SnippetTestData
    var possibleMissingWords: [String]? {
        return self.possibleMissingWordList as? [String]
    }
    
    // For StatementTestData
    var answers: [String: Bool]? {
        return self.answerDictionary as? [String: Bool]
    }
    
    func returnAsTestDataObject() -> TestDataProtocol {
        if self.snippets != nil && self.taskDescription != nil && self.possibleMissingWords != nil {
            return SnippetTestData(taskDescription: self.taskDescription!, snippets: self.snippets!, possibleMissingWords: self.possibleMissingWords!)
        } else {
            return StatementTestData(question: self.question!, startOfAnswer: self.startOfAnswer!, answers: self.answers!)
        }
    }
    
    // Convenience initializer for SnippetTestData
    convenience init?(taskDescription: String){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: TestData.entity(), insertInto: context)
        self.taskDescription = taskDescription
        addTestTypeDataToValidTestTypeList(types: testTypeForSnippetTestData)
    }
    
    // Convenience initializer for StatementTestData
    convenience init?(question: String, startOfAnswer: String){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: TestData.entity(), insertInto: context)
        self.question = question
        self.startOfAnswer = startOfAnswer
        addTestTypeDataToValidTestTypeList(types: testTypeForStatementTestData)
    }
    
    private func addTestTypeDataToValidTestTypeList(types: [TestType]) {
        var testData = [String]()
        for type in types {
            testData.append(type.description)
        }
        self.validTestTypeList = testData as NSObject
    }
}
