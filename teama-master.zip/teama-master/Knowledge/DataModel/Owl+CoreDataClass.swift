//
//  Owl+CoreDataClass.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

@objc(Owl)
public class Owl: NSManagedObject {

    var inventory: [Book] {
        return self.bookList?.allObjects as! [Book]
    }
    
    var hunger: Int {
        set(newValue) {
            self.hungerInt16 = Int16(newValue)
        }
        get {
            return Int(self.hungerInt16)
        }
    }
    
    var affection: Int {
        set(newValue) {
            self.affectionInt16 = Int16(newValue)
        }
        get {
            return Int(self.affectionInt16)
        }
    }
    
    var currentEmotion: Emotion {
        set(newValue){
            self.currentEmotionString = newValue.description
        }
        get {
            return Emotion(rawValue: currentEmotionString!)!
        }
    }
    
    var currentLevel: Int {
        set(newValue) {
            self.currentLevelInt16 = Int16(newValue)
        }
        get {
            return Int(self.currentLevelInt16)
        }
    }
    
    var pointsLeftForNextLevel: Int {
        set(newValue) {
            self.pointsLeftForNextLevelInt16 = Int16(newValue)
        }
        get {
            return Int(self.pointsLeftForNextLevelInt16)
        }
    }
    
    var reachedPoints: Int {
        set(newValue) {
            self.reachedPointsInt16 = Int16(newValue)
        }
        get {
            return Int(self.reachedPointsInt16)
        }
    }
    
    convenience init?(name: String, reachedPoints: Int){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: Owl.entity(), insertInto: context)
        let emotion: Emotion = .normal
        self.affectionInt16 = Int16(100)
        self.currentLevelInt16 = Int16(1)
        self.currentEmotionString = emotion.description
        self.hungerInt16 = Int16(100)
        self.name = name
        self.reachedPointsInt16 = Int16(reachedPoints)
        self.lastInteractionTimestamp = Date()
        self.lastSolvedTestTimestamp = Date()
    }
    
}
