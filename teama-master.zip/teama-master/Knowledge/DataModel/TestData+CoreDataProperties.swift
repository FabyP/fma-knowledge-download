//
//  TestData+CoreDataProperties.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData

/**
Generated extension for testData, which contains data types of the model in Knowledge.xcdatamodeld
*/
extension TestData {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TestData> {
        return NSFetchRequest<TestData>(entityName: "TestData")
    }

    @NSManaged public var answerDictionary: NSObject?
    @NSManaged public var possibleMissingWordList: NSObject?
    @NSManaged public var question: String?
    @NSManaged public var snippetList: NSObject?
    @NSManaged public var startOfAnswer: String?
    @NSManaged public var taskDescription: String?
    @NSManaged public var validTestTypeList: NSObject
    @NSManaged public var lesson: Lesson?
    @NSManaged public var testExcercise: NSSet?

}

// MARK: Generated accessors for testExcercise
extension TestData {

    @objc(addTestExcerciseObject:)
    @NSManaged public func addToTestExcercise(_ value: TestExercise)

    @objc(removeTestExcerciseObject:)
    @NSManaged public func removeFromTestExcercise(_ value: TestExercise)

    @objc(addTestExcercise:)
    @NSManaged public func addToTestExcercise(_ values: NSSet)

    @objc(removeTestExcercise:)
    @NSManaged public func removeFromTestExcercise(_ values: NSSet)

}
