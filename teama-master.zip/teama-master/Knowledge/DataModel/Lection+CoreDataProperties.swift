//
//  Lection+CoreDataProperties.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData


extension Lection {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Lection> {
        return NSFetchRequest<Lection>(entityName: "Lection")
    }

    @NSManaged public var alreadySeen: Bool
    @NSManaged public var title: String?
    @NSManaged public var lectionTextes: NSSet?
    @NSManaged public var lesson: Lesson?
    @NSManaged public var index: Int16
}

// MARK: Generated accessors for lectionTextes
extension Lection {

    @objc(addLectionTextesObject:)
    @NSManaged public func addToLectionTextes(_ value: LectionText)

    @objc(removeLectionTextesObject:)
    @NSManaged public func removeFromLectionTextes(_ value: LectionText)

    @objc(addLectionTextes:)
    @NSManaged public func addToLectionTextes(_ values: NSSet)

    @objc(removeLectionTextes:)
    @NSManaged public func removeFromLectionTextes(_ values: NSSet)

}
