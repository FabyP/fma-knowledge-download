//
//  Lesson+CoreDataProperties.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData

/**
 Generated extension for lesson, which contains data types of the model in Knowledge.xcdatamodeld
 */
extension Lesson {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Lesson> {
        return NSFetchRequest<Lesson>(entityName: "Lesson")
    }

    @NSManaged public var atLeastOneTestSerieSolvedCorrectly: Bool
    @NSManaged public var imageName: String?
    @NSManaged public var intendedNumberOfExercisesInt16: Int16
    @NSManaged public var name: String?
    @NSManaged public var currentTestExerciseList: NSSet?
    @NSManaged public var lectionList: NSSet?
    @NSManaged public var testDataList: NSSet?

}

// MARK: Generated accessors for currentTestExerciseList
extension Lesson {

    @objc(addCurrentTestExerciseListObject:)
    @NSManaged public func addToCurrentTestExerciseList(_ value: TestExercise)

    @objc(removeCurrentTestExerciseListObject:)
    @NSManaged public func removeFromCurrentTestExerciseList(_ value: TestExercise)

    @objc(addCurrentTestExerciseList:)
    @NSManaged public func addToCurrentTestExerciseList(_ values: NSSet)

    @objc(removeCurrentTestExerciseList:)
    @NSManaged public func removeFromCurrentTestExerciseList(_ values: NSSet)

}

// MARK: Generated accessors for lectionList
extension Lesson {

    @objc(addLectionListObject:)
    @NSManaged public func addToLectionList(_ value: Lection)

    @objc(removeLectionListObject:)
    @NSManaged public func removeFromLectionList(_ value: Lection)

    @objc(addLectionList:)
    @NSManaged public func addToLectionList(_ values: NSSet)

    @objc(removeLectionList:)
    @NSManaged public func removeFromLectionList(_ values: NSSet)

}

// MARK: Generated accessors for testDataList
extension Lesson {

    @objc(addTestDataListObject:)
    @NSManaged public func addToTestDataList(_ value: TestData)

    @objc(removeTestDataListObject:)
    @NSManaged public func removeFromTestDataList(_ value: TestData)

    @objc(addTestDataList:)
    @NSManaged public func addToTestDataList(_ values: NSSet)

    @objc(removeTestDataList:)
    @NSManaged public func removeFromTestDataList(_ values: NSSet)

}
