//
//  TestType.swift
//  ProjectTest
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import Foundation

// Possible TestTypes for TestExercises
public enum TestType: String, CaseIterable {
    case quiz, trueOrFalse, sortSnippets, cloze
    
    var description: String {
        switch self {
            case .quiz: return "quiz"
            case .trueOrFalse: return "trueOrFalse"
            case .sortSnippets: return "sortSnippets"
            case .cloze: return "cloze"
        }
    }
}
