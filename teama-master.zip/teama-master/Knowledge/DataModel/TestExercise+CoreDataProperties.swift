//
//  TestExercise+CoreDataProperties.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData


extension TestExercise {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<TestExercise> {
        return NSFetchRequest<TestExercise>(entityName: "TestExercise")
    }

    @NSManaged public var solved: Bool
    @NSManaged public var solvedCorrect: Bool
    @NSManaged public var testType: String
    @NSManaged public var lesson: Lesson?
    @NSManaged public var usedTestData: TestData
    @NSManaged public var indexInt16: Int16
    
}
