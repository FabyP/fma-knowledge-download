//
//  Lection+CoreDataClass.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

@objc(Lection)
public class Lection: NSManagedObject {

    var texts: [LectionText] {
        return (self.lectionTextes?.allObjects as! [LectionText]).sorted { (l1, l2) -> Bool in
            Int(l1.index) < Int(l2.index)
        }
    }
    
    convenience init?(title: String, index: Int){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: Lection.entity(), insertInto: context)
        self.alreadySeen = false
        self.title = title
        self.index = Int16(index)
    }
}
