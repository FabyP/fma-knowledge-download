//
//  LevelDesigner.swift
//  Knowledge
//
//  Created by FMA1 on 08.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import Foundation

/*
 *  Helper class for level and images
 */
class LevelDesigner {
    
    private static let thresholdHunger = 10
    private static let thresholdAffection = 20
    
    private static let imageAdditionForClosedEyes = "_eyes_closed"
    private static let imageAdditionForOpenMouth = "_with_open_mouth"
    
    static let timeIntervalForNeedsInSeconds: Double = 30 //5 * 60
    static let amountOfReducedAffectionInTimeInterval = 2
    static let amountOfReducedHungerInTimeInterval = 1
    static let boredAfterSecondsWithoutSolvingTests = 3600.0 // 86400.0 * 2
    
    private static let secondsInAnHour = 3600.0
    private static let secondsInDays = 86400.0
    
    private static let neededPointsForLevel = [
        1 : 0, // baby owl
        2 : 2, // baby owl with glasses
        3 : 4, // adult owl
        4 : 5  // adult owl with hat
    ]
    
    private static let imageNameForLevel = [
        1 : "owl_small",
        2 : "owl_small_glasses",
        3 : "owl_adult",
        4 : "owl_adult_hat"
    ]
    
    private static let imageNameForEmotion = [
        Emotion.angry: "_angry",
        Emotion.bored: "_bored",
        Emotion.normal: "_normal",
        Emotion.sad: "_sad",
        Emotion.happy: "_action"
    ]
    
    static let iconNameForNeeds = [
        Emotion.angry: "hunger_icon",
        Emotion.bored: "knowledge_icon",
        Emotion.sad: "affection_icon",
    ]
    
    static func getCurrentLevel(reachedPoints: Int) -> Int {
        var currentLevel = 1
        for (key,value) in neededPointsForLevel.sorted(by: {$0.key < $1.key}) {
            if value <= reachedPoints {
                currentLevel = key
            } else {
                return currentLevel
            }
        }
        return currentLevel
    }
    
    static func getIconNamesToAnimate(affection: Int, hunger: Int, lastSolvedTimestamp: Date) -> [String] {
        var list = [String]()
        let currentDate = Date()
        let distanceBetweenDates = currentDate.timeIntervalSince(lastSolvedTimestamp)
        
        if hunger <= thresholdHunger {
            list.append(iconNameForNeeds[.angry]!)
        }
        if affection <= thresholdAffection {
            list.append(iconNameForNeeds[.sad]!)
        }
        if distanceBetweenDates >= boredAfterSecondsWithoutSolvingTests {
            list.append(iconNameForNeeds[.bored]!)
        }
        return list
    }
    
    static func neededPoints(for level: Int) -> Int {
        if let points = neededPointsForLevel[level] {
            return points
        }
        return 0
    }
    
    static func getImageNameForEmotionAndLevel(emotion: Emotion, level: Int) -> String {
        var image: String = imageNameForLevel[level]!
        image = image + imageNameForEmotion[emotion]!
        return image
    }
    
    static func getImageNameWhileFeedingForEmotionAndLevel(emotion: Emotion, level: Int) -> String {
        var image: String = imageNameForLevel[level]!
        image = image + imageNameForEmotion[emotion]!
        image = image + imageAdditionForOpenMouth
        return image
    }
    
    static func getImageNameWhileBlinkForLevel(level: Int) -> String {
        var image: String = imageNameForLevel[level]!
        image = image + imageAdditionForClosedEyes
        return image
    }
    
    static func calculateEmotion(affection: Int, hunger: Int, lastSolvedTimestamp: Date) -> Emotion {
        let currentDate = Date()
        let distanceBetweenDates = currentDate.timeIntervalSince(lastSolvedTimestamp)

        if affection <= thresholdAffection {
            return .sad
        } else if hunger <= thresholdHunger {
            return .angry
        } else if distanceBetweenDates >= boredAfterSecondsWithoutSolvingTests {
            return .bored
        }
        return .normal
    }
    
    static func calculatePercentageOfKnowledgeNeed(lastSolvedTimestamp: Date) -> Int {
        let currentDate = Date()
        let distanceBetweenDates = currentDate.timeIntervalSince(lastSolvedTimestamp)
        let percentage = 100.0 - 100.0/boredAfterSecondsWithoutSolvingTests * distanceBetweenDates
        return max(Int(percentage), 0)
    }
    
    static func getAdditionForAction() -> String {
        return imageNameForEmotion[.happy]!
    }
    
    static func getAdditionForFeeding() -> String {
        return imageAdditionForOpenMouth
    }
    
}
