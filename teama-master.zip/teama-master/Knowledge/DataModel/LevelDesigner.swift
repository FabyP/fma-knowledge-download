//
//  LevelDesigner.swift
//  Knowledge
//
//  Created by FMA1 on 08.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import Foundation

/*
 *  Helper class for level and images
 */
class LevelDesigner {
    // Thresholds for needs
    private static let thresholdHunger = 10
    private static let thresholdAffection = 20
    static let boredAfterSecondsWithoutSolvingTests = 3600.0 // 86400.0 * 2
    
    private static let imageAdditionForClosedEyes = "_eyes_closed"
    private static let imageAdditionForOpenMouth = "_with_open_mouth"
    
    // Interval and amount to reduce
    static let timeIntervalForNeedsInSeconds: Double = 30 //5 * 60
    static let amountOfReducedAffectionInTimeInterval = 2
    static let amountOfReducedHungerInTimeInterval = 1

    private static let secondsInAnHour = 3600.0
    private static let secondsInDays = 86400.0
    
    // Returns how many points Owlsome needs for a special level
    private static let neededPointsForLevel = [
        1 : 0, // baby owl
        2 : 2, // baby owl with glasses
        3 : 4, // adult owl
        4 : 5  // adult owl with hat
    ]
    
    // Part of image name: Level (Stage of development)
    private static let imageNameForLevel = [
        1 : "owl_small",
        2 : "owl_small_glasses",
        3 : "owl_adult",
        4 : "owl_adult_hat"
    ]
    
    // Part of image name: Emotion (Because of needs)
    private static let imageNameForEmotion = [
        Emotion.angry: "_angry",
        Emotion.bored: "_bored",
        Emotion.normal: "_normal",
        Emotion.sad: "_sad",
        Emotion.happy: "_action"
    ]
    
    // Icon names for special needs (associated with their emotions)
    static let iconNameForNeeds = [
        Emotion.angry: "hunger_icon",
        Emotion.bored: "knowledge_icon",
        Emotion.sad: "affection_icon",
    ]
    
    // Returns current level of Owlsome by reachedPoints
    static func getCurrentLevel(reachedPoints: Int) -> Int {
        var currentLevel = 1
        for (key,value) in neededPointsForLevel.sorted(by: {$0.key < $1.key}) {
            if value <= reachedPoints {
                currentLevel = key
            } else {
                return currentLevel
            }
        }
        return currentLevel
    }
    
    // Returns names of need icons for unfulfilled needs
    static func getIconNamesToAnimate(affection: Int, hunger: Int, lastSolvedTimestamp: Date) -> [String] {
        var list = [String]()
        let currentDate = Date()
        let distanceBetweenDates = currentDate.timeIntervalSince(lastSolvedTimestamp)
        
        if hunger <= thresholdHunger {
            list.append(iconNameForNeeds[.angry]!)
        }
        if affection <= thresholdAffection {
            list.append(iconNameForNeeds[.sad]!)
        }
        if distanceBetweenDates >= boredAfterSecondsWithoutSolvingTests {
            list.append(iconNameForNeeds[.bored]!)
        }
        return list
    }
    
    // Returns number of points which are needed for a special level
    static func neededPoints(for level: Int) -> Int {
        if let points = neededPointsForLevel[level] {
            return points
        }
        return 0
    }
    
    // Returns full image name for Owlsome (for emotion and level)
    static func getImageNameForEmotionAndLevel(emotion: Emotion, level: Int) -> String {
        var image: String = imageNameForLevel[level]!
        image = image + imageNameForEmotion[emotion]!
        return image
    }
    
    // Returns full image name for Owlsome with open mouth
    static func getImageNameWhileFeedingForEmotionAndLevel(emotion: Emotion, level: Int) -> String {
        var image: String = imageNameForLevel[level]!
        image = image + imageNameForEmotion[emotion]!
        image = image + imageAdditionForOpenMouth
        return image
    }
    
    // Returns full image name for Owlsome with closed eyes
    static func getImageNameWhileBlinkForLevel(level: Int) -> String {
        var image: String = imageNameForLevel[level]!
        image = image + imageAdditionForClosedEyes
        return image
    }
    
    // Calculate current Emotion (Affection is stronger than hunger and they are stronger than boredom)
    static func calculateEmotion(affection: Int, hunger: Int, lastSolvedTimestamp: Date) -> Emotion {
        let currentDate = Date()
        let distanceBetweenDates = currentDate.timeIntervalSince(lastSolvedTimestamp)

        if affection <= thresholdAffection {
            return .sad
        } else if hunger <= thresholdHunger {
            return .angry
        } else if distanceBetweenDates >= boredAfterSecondsWithoutSolvingTests {
            return .bored
        }
        return .normal
    }
    
    // Calculate percentage of knowledge need for label
    static func calculatePercentageOfKnowledgeNeed(lastSolvedTimestamp: Date) -> Int {
        let currentDate = Date()
        let distanceBetweenDates = currentDate.timeIntervalSince(lastSolvedTimestamp)
        let percentage = 100.0 - 100.0/boredAfterSecondsWithoutSolvingTests * distanceBetweenDates
        return max(Int(percentage), 0)
    }
    
    // Returns part of image name for emotion happy
    static func getAdditionForAction() -> String {
        return imageNameForEmotion[.happy]!
    }
    
    // Returns part of image name for open mouth
    static func getAdditionForFeeding() -> String {
        return imageAdditionForOpenMouth
    }
    
}
