//
//  Owl+CoreDataProperties.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData

/**
Generated extension for owl, which contains data types of the model in Knowledge.xcdatamodeld
*/
extension Owl {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Owl> {
        return NSFetchRequest<Owl>(entityName: "Owl")
    }

    @NSManaged public var affectionInt16: Int16
    @NSManaged public var currentEmotionString: String?
    @NSManaged public var currentLevelInt16: Int16
    @NSManaged public var hungerInt16: Int16
    @NSManaged public var name: String?
    @NSManaged public var pointsLeftForNextLevelInt16: Int16
    @NSManaged public var reachedPointsInt16: Int16
    @NSManaged public var bookList: NSSet?
    @NSManaged public var lastInteractionTimestamp: Date
    @NSManaged public var lastSolvedTestTimestamp: Date

}

// MARK: Generated accessors for bookList
extension Owl {

    @objc(addBookListObject:)
    @NSManaged public func addToBookList(_ value: Book)

    @objc(removeBookListObject:)
    @NSManaged public func removeFromBookList(_ value: Book)

    @objc(addBookList:)
    @NSManaged public func addToBookList(_ values: NSSet)

    @objc(removeBookList:)
    @NSManaged public func removeFromBookList(_ values: NSSet)

}
