//
//  Book+CoreDataClass.swift
//  Knowledge
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//
//

import Foundation
import CoreData
import UIKit

@objc(Book)
public class Book: NSManagedObject {

    // Returns points as Int
    var points: Int {
        return Int(pointsInt16)
    }
    
    // book enum with imageName and feeding points and which percentage of correct solved test exercises are needed
    enum books {
        case gold, silver, bronze
        var imageName: String {
            switch self {
                case .gold: return "book_gold"
                case .silver: return "book_silver"
                case .bronze: return "book_bronze"
            }
        }
        var percentNeeded: Double {
            switch self {
                case .gold: return 100
                case .silver: return 50
                case .bronze: return 0
            }
        }
        
        var points: Int {
            switch self {
                case .gold: return 100
                case .silver: return 50
                case .bronze: return 25
            }
        }
    }
    
    // Returns points for book by percentage of correct solved test exercises
    static func getPoints(by percent: Double) -> Int {
        if percent == books.gold.percentNeeded {
            return books.gold.points
        } else if percent >= books.silver.percentNeeded {
            return books.silver.points
        } else {
            return books.bronze.points
        }
    }
    
    // Returns image name of book by percentage of correct solved test exercises
    static func getImageName(by percent: Double) -> String {
        if percent == books.gold.percentNeeded {
            return books.gold.imageName
        } else if percent >= books.silver.percentNeeded {
            return books.silver.imageName
        } else {
            return books.bronze.imageName
        }
    }
    
    convenience init?(points: Int, imageName: String){
        let container: NSPersistentContainer? = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer
        guard let context = container?.viewContext else { return nil }
        
        self.init(entity: Book.entity(), insertInto: context)
        self.pointsInt16 = Int16(points)
        self.imageName = imageName
    }
}
