//
//  Emotion.swift
//  ProjectTest
//
//  Created by FMA1 on 07.06.20.
//  Copyright © 2020 FMA1. All rights reserved.
//

import Foundation

public enum Emotion: String {
    case normal, happy, angry, sad, bored
    
    var description: String {
        switch self {
            case .normal: return "normal"
            case .happy: return "happy"
            case .angry: return "angry"
            case .sad: return "sad"
            case .bored: return "bored"
        }
    }
}
