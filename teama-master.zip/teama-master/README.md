# Readme
Stand: 19.06.2020
## Getting Started

1. Das Projekt klonen
2. Mit XCode den Unterordner team a &ouml;ffnen
3. Die App mit dem Simulator von XCode starten

Relevante Interaktionen vom Nutzer werden bereits gespeichert. Solltet ihr die App noch einmal neu/ von vorne starten wollen, m&uuml;sst ihr im Simulator die App 1x deinstallieren (dh. einmal auf den Homebutton klicken; dann lange auf das App-Icon klicken und dann im Popup den L&ouml;schvorgang best&auml;tigen).

Ein wichtiger Hinweis: Falls sich euer Keyboard bei den L&uuml;ckentexten nicht &ouml;ffnet, kann das an den Einstellungen von XCode liegen: wenn ihr im Simulator seid, w&auml;hlt oben im Men&uuml;I/O > Keyboard aus und w&auml;hlt "Connect Hardware Keyboard" ab. (Manchmal muss man es auch einmal abw&auml;hlen, dann wieder ausw&auml;hlen und dann wieder abw&auml;hlen, damit es geht).

##Welche Teile sind bereit zum Testen ?
- **Interaktion mit Owlsome**: Man kann auf Owlsome tippen und dar&uuml;ber swipen und entsprechend folgt eine kleine Animation als Reaktion. (Das soll Owlsome lebendiger und niedlicher erscheinen lassen)
- Wir haben aktuell **3 beispielhafte Lerneinheiten (lessons)** erstellt. Unter dem Men&uuml;punkt "Learn" sind diese aufgef&uuml;hrt
- Beim &ouml;ffnen einer Lesson werden verschiedene **Lektionen gezeigt**, die per Swipe durchlaufen werden k&ouml;nnen
- Wenn alle Lektionen einer Lesson angesehen wurden, kann man unter dem Men&uuml;punkt "Tests" eine zugeh&ouml;rige **Testreihe** starten. Dazu tippt man einfach auf den Start-Button einer freigeschalteten Lesson
- Wir haben alle vorgesehenen **Testarten** implementiert:
	- Quiz
	- Wahr oder Falsch
	- Code sortieren
	- L&uuml;ckentext
Das Model ist hierbei genau so aufgebaut, wie es im Feinkonzept beschrieben wurde. Um die Daten geeignet mit Hilfe von Core Data abzuspeichern mussten jedoch kleiner &Auml;nderungen vorgenommen werden (bspw. k&ouml;nnen keine optionalen Booleans gespeichert werden etc.)
- Eine Testreihe kann vollst&auml;ndig absolviert und danach auch wiederholt werden.

## Welche Teile sind noch in Planung ?
F&uuml;r die Zwischenabgabe haben wir uns auf die Darstellung von Lektionen und das Absolvieren von Testreihen konzentriert. Folgende Funktionen werden entsprechend erst sp&auml;ter realisiert.
- Die Bed&uuml;rfnisse von Owlsome, sowie sein Stufenaufstieg und die F&uuml;tterung sind noch nicht vorhanden
- Man verdient noch keine B&uuml;cher, die an Owlsome verf&uuml;ttert werden k&ouml;nnen (auch wenn bei der Evaluation des Tests schon darauf hingewiesen wird)

## Wo treten Bugs auf ?
- Bugs, die einen Absturz der App verursachen, sind uns nicht bekannt
- Es gibt teilweise noch leichte Probleme mit dem Layout (dass noch nicht alle Screens im Landscape-Modus funktionieren und allgemein nicht scrollable sind)

## Wo br&auml;uchten wir besonders Feedback ?
- Zum Schwierigkeitsgrad der Tests (falls mit einer bestimmten Aufgabenstellung eines Tests etwas nicht stimmen sollte, dann gebt bitte Hinweise zu manchen Eckdaten, dass wir den Test in unseren Beispieldaten identifizieren kรถnnen)
- Am Ende einer Lesson, wenn man die letzte Lektion erreicht hat (zb 3/3) und noch einmal weiter swipt รถffnet sich ein Popup, das einen zu den Tests bringen kann. Was haltet ihr von dieser Funktion?

##Welche Entscheidungen haben wir aufgrund des Feedbacks getroffen ?
Wir haben viel Feedback erhalten und uns innerhalb des Teams mit allen Punkten befasst. Danach haben wir folgende (finale) Entscheidungen f&uuml;r unsere App getroffen:
- **Levelaufstieg von Owlsome:**
Beonders hier gab es unterschiedliche Vorschl&auml;ge, wie man einen Anreiz f&uuml;r den Nutzer schaffen kann, dass er die App nach einmaligem Spielen weiterhin Nutzen m&ouml;chte. Man k&ouml;nnte die App x-Mal durchlaufen und erst dann w&auml;re Owlsome ausgewachsen oder man k&ouml;nnte sich danach um eine neue Eule k&uuml;mmern und festhalten, wie viele man schon versorgt hat. Beide Vorschl&auml;ge sind interssant und umsetzbar, konnten uns aber nicht &uuml;berzeugen. Es geht bei uns gezielt um die Bindung zu genau einer Eule (Owlsome) und es soll auch ersichtlich sein, was das Ziel der App ist (n&auml;mlich alle Tests richtig zu absolvieren). Die Anzahl der Punkte f&uuml;r einen Aufstieg werden wir anpassen, je nachdem, wie viele Lessons und wie viele Wachstums-Etappen wir f&uuml;r Owlsome haben
- **Owlsome als Joker bei den Aufgaben einsetzen**
Dieser Vorschlag hat uns gut gefallen und wir haben es zu Beginn unseres Grobkonzepts auch schon in Erw&auml;gung gezogen. Aus zeitlichen Gr&uuml;nden werden wir diese Funktion jedoch wahrscheinlich nicht umsetzen k&ouml;nnen.
- **Belohnungssystem bei der Absolvierung von Tests**
Auch hier gab es sehr unterschiedliche Meinungen: Einmal wurde dazu geraten und einmal davon abgeraten. Wenn wir es zeitlich schaffen, wollen wir tats&auml;chlich eine Staffelung der Punkte vornehmen, aber auf eine Weise, die den Nutzer nicht demotiviert:
	- Owlsome sollen Punkte gutgeschrieben werden, wenn eine Testreihe einer Lesson zum ersten Mal komplett vollst&auml;ndig gel&ouml;st wurde. (Bei einer bestimmten Anzahl von Punkten findet ein Levelaufstieg statt, wobei sich Owlsomes aussehen entsprechend anpassen wird)
	- In jedem Fall bekommt der Nutzer nach der Absolvierung eines Tests ein Buch gutgeschrieben, das an Owlsome verf&uuml;ttert werden kann: Je nachdem wie viel Prozent der Tests richtig gel&ouml;st wurden, soll das Buch gold, silber oder bronze sein und den Hunger von Owlsome unterschiedlich stark stillen. (Das soll dazu f&uuml;ren, dass der Nutzer sich in jedem Fall bei den Tests M&uuml;he gibt und nicht einfach wahllos rumtippt, damit er etwas bekommt).
- **Design**
Da "Learn" und "Tests" zwei separate Men&uuml;punkte sind, haben wir es nicht als st&ouml;rend empfunden sowohl Cards als auch Tabellen bei unserer App zu verwenden. Deswegen sind wir bei unserem Entwurf geblieben, da er uns optisch gut gefallen hat.
