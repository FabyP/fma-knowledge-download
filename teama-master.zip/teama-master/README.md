# Readme
Stand: 08.07.2020

**Team A:**
- Fabienne Pipping (5109333)
- Melvin Schmidt (5147447)
- Franziska Wild (5308082)

## Getting Started

1. Das Projekt klonen
2. Mit XCode den Unterordner team a &ouml;ffnen
3. Die App mit dem Simulator von XCode starten

Der Fortschritt der App wird kontinuierlich gespeichert. Wenn die App noch einmal neu/ von vorne gestartet werden soll, muss die App im Simulator deinstalliert werden (dh. einmal auf den Homebutton klicken; dann lange auf das App-Icon klicken und dann im Popup den L&ouml;schvorgang best&auml;tigen).

**Ein wichtiger Hinweis:** Falls sich das Keyboard bei den L&uuml;ckentexten nicht &ouml;ffnet, kann das an den Einstellungen von XCode liegen: Um das zu beheben muss man (wenn man im Simulator ist), oben im Men&uuml; I/O > Keyboard > "Connect Hardware Keyboard" abw&auml;hlen. (Manchmal muss man es auch einmal abw&auml;hlen, dann wieder ausw&auml;hlen und dann wieder abw&auml;hlen, damit es geht).

## Features der App
**Swift lernen**
- Beim ersten Start der App wird eine einleitende **Slideshow** gezeigt, die den Nutzer mit den Funktionen und dem Nutzen der App vertraut macht.
- Im **"Learn"-Bereich** kann der Nutzer verschiedene Swiftthemen ausw&auml;hlen. Nach der Auswahl kann er per Swipe deren verschiedenen Lektionen durchgehen. Dabei werden erkl&auml;rende Texte und Codebeispiele verwendet, um den Inhalt geeignet zu vermitteln.

**Swift Wissen testen**
- Nachdem alle Lektionen eines Themenbereichs vollst&auml;ndig durchgegangen wurden, wird ein dazugeh&ouml;riger Test im **"Test"-Bereich** freigeschaltet. Jeder Themenbereich hat eine unterschiedliche Anzahl an bereitgestellten Testaufgaben, die auf den Inhalt des Themenbereich abgestimmt sind.
- Die Teste werden dynamisch aus "TestData"-Objekten generiert. Dabei kann aus einem Objekt zwei verschiedene Arten von Aufgabentypen generiert werden. Die Typen und die TestData werden zuf&auml;llig gew&auml;hlt vom System ausgew&auml;hlt.
- Es gibt vier **verschiedene Testaufgaben**:
	- L&uuml;ckentext (Codes vervollst&auml;ndigen)
	- Sortierteste (Codebl&ouml;cke in die richtige Reihenfolge bringen)
	- Quiz (Auswahl einer richtigen Antwort aus vier M&ouml;glichkeiten)
	- Aussagen bewerten (True Or False)
- Nach jeder Aufgabe bekommt der Nutzer einen visuellen Hinweis, ob seine Antwort richtig oder falsch ist.
- Am Ende einer Testreihe wird das Gesamtresultat zusammengefasst.
- Nachdem eine Testreihe abgeschlossen wurde, wird dem Nutzer bzw. Owlsome ein **Buch** gutgeschrieben, das an Owlsome verf&uuml;ttert werden kann. Die Farbe des Buches dr&uuml;ckt aus, wie s&auml;ttigend es f&uuml;r Owlsome ist:
	- gold: 100%
	- silber: 50%
	- bronze: 25%
- Wenn eine Testreihe eines Themenbereichs **einmal vollst&auml;ndig richtig** absolviert wurde, wird Owlsome ein Punkt gutgeschrieben. Mit einer bestimmten Anzahl von Punkten steigt Owlsome ein **Level** auf und w&auml;chst entsprechend, wodurch sich das Aussehen entsprechend anpasst.

**Owlsome**
- Im **"Care"-Bereich** findet man Owlsome, die kleine Eule, um die man sich k&uuml;mmern soll. Oben befindet sich die Bed&uuml;rfnissleiste und unten das Inventar von Owlsome, in dem die verdienten B&uuml;cher aufgelistet sind.
- Owlsomes **Bed&uuml;rfnisse** k&ouml;nnen auf folgende Weise erf&uuml;llt werden:
	- **Hunger**: Owlsome kann mit verdienten B&uuml;chern gef&uuml;ttert werden. Dazu kann ein Buch (sofern die Anzahl von diesem > 1 ist) per Drag&Drop zu ihm gezogen werden. (Zur Auswahl eines Buches ist ein "Longpress" notwendig)
	- **Zuneigung**: Owlsome braucht viel Liebe und Aufmerksamkeit. Man kann mit Owlsome interagieren, indem man auf ihn tippt und &uuml;ber ihn streichelt (swipt). Er wird entsprechend mit einer kleinen Animation reagieren.
	- **Lerneifer**: Owlsome ist eine Eule und will was Lernen und Weisheit sammeln. Owlsome wird langweilig, wenn in einer bestimmten Zeit, keine Testreihen (vollst&auml;ndig) absolviert wurden.
- Die **Bed&uuml;rfnis-Icons** werden animiert, wenn das entsprechende Bed&uuml;rfnis unter einen bestimmten Schwellwert sinkt. Unter dem Icon wird die prozentuale Erf&uuml;llung des Bed&uuml;rfnis angezeigt (100% = voll erf&uuml;llt). Die  Bed&uuml;rfnisse sinken unterschiedlich schnell und jedes hat einen eigenen Schwellwert. Owlsome reagiert bei einer Nichterf&uuml;llung der Bed&uuml;rfnisse mit einer entsprechenden Emotion. (Sein Gesichtsausdruck passt sich entsprechend an).
- Wenn Owlsome ein Level aufsteigt, wird entsprechend dies mit einer kleinen Animation visualisiert (vom alten zum neuen Aussehen). Wenn die Testreihen aller Lerneinheiten (mindestens) einmal vollst&auml;ndig absolviert wurden, ist Owlsome erwachsen und tr&auml;gt einen Absolventenhut. Doch auch danach m&ouml;chte er stets Teste wiederholen und versorgt werden.
